<?php

namespace Core\Container;

use Core\Container\Interfaces\DelegationPolicy;
use Psr\Container\ContainerInterface;

/**
 * Implementasi default dari DelegationPolicy yang selalu mengizinkan
 * delegasi resolusi layanan ke kontainer induk.
 *
 * @package Core\Container
 * @implements DelegationPolicy
 */
class AllowAllPolicy implements DelegationPolicy
{
    /**
     * @inheritDoc
     */
    public function canDelegate(string $id, ContainerInterface $child, ContainerInterface $parent): bool
    {
        return true;
    }
}

