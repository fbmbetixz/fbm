<?php

namespace Core\Container;

use Core\Container\Interfaces\SnapshotManager;
use Core\Container\NextLevelContainer;

/**
 * Implementasi default dari SnapshotManager.
 * Mengelola ekspor, impor, dan diff status kontainer atau tenant menggunakan JSON.
 *
 * @package Core\Container
 * @implements SnapshotManager
 */
class DefaultSnapshotManager implements SnapshotManager
{
    /**
     * @inheritDoc
     */
    public function export(array $state, ?string $file = null): ?string
    {
        $json = json_encode($state, JSON_PRETTY_PRINT);
        if ($file) {
            file_put_contents($file, $json);
            return null;
        }
        return $json;
    }

    /**
     * @inheritDoc
     */
    public function import(string|array $data): array
    {
        if (is_string($data) && file_exists($data)) {
            $data = file_get_contents($data);
        }
        return is_array($data) ? $data : json_decode($data, true);
    }

    /**
     * @inheritDoc
     */
    public function diff(array $a, array $b): array
    {
        return [
            'added' => array_diff_key($b, $a),
            'removed' => array_diff_key($a, $b),
            'changed' => array_diff_assoc($b, $a) // Hanya mendeteksi perubahan nilai pada kunci yang sama
        ];
    }

    /**
     * @inheritDoc
     */
    public function exportTenants(array $tenants): array
    {
        $snapshots = [];
        foreach ($tenants as $tid => $tenant) {
            if ($tenant instanceof NextLevelContainer) {
                $snapshots[$tid] = $tenant->exportSnapshotArray();
            } else {
                $snapshots[$tid] = null; // Atau tangani tipe tenant lain sesuai kebutuhan
            }
        }
        return $snapshots;
    }

    /**
     * @inheritDoc
     */
    public function importTenants(array $snaps, callable $factory): array
    {
        $tenants = [];
        foreach ($snaps as $tid => $snap) {
            $tenant = $factory();
            if ($tenant instanceof NextLevelContainer) {
                $tenant->importSnapshotArray($snap);
            }
            $tenants[$tid] = $tenant;
        }
        return $tenants;
    }
}

