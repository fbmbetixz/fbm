<?php

namespace Core\Container;

use Core\Container\Exceptions\CircularDependencyException;
use Core\Container\Interfaces\BindingRegistry;

/**
 * Implementasi BindingRegistry berbasis memori.
 * Menyimpan definisi binding, alias, tag, dekorator, tipe ketat, dan pengaturan kedaluwarsa.
 *
 * @package Core\Container
 * @implements BindingRegistry
 */
class InMemoryBindingRegistry implements BindingRegistry
{
    /** @var array<string, array> Definisi binding. */
    private array $bindings = [];
    /** @var array<string, string> Alias layanan. */
    private array $aliases = [];
    /** @var array<string, array<string, bool>> Tag layanan. */
    private array $tags = [];
    /** @var array<string, callable[]> Dekorator layanan. */
    private array $decorators = [];
    /** @var array<string, string> Tipe ketat layanan. */
    private array $strictTypes = [];
    /** @var array<string, array{expire_at: int, ttl: int, sliding: bool}> Pengaturan kedaluwarsa layanan. */
    private array $expiry = [];

    /**
     * Mengkloning instance registri.
     * Memastikan array internal di-copy by value.
     */
    public function __clone()
    {
        $this->bindings = $this->bindings;
        $this->aliases = $this->aliases;
        $this->tags = $this->tags;
        $this->decorators = $this->decorators;
        $this->strictTypes = $this->strictTypes;
        $this->expiry = $this->expiry;
    }

    /**
     * Memastikan ID layanan valid (tidak kosong atau mengandung spasi).
     *
     * @param string $id ID layanan yang akan divalidasi.
     * @throws \InvalidArgumentException Jika ID tidak valid.
     * @return void
     */
    protected function assertValidId(string $id): void
    {
        if (trim($id) === '' || str_contains($id, ' ')) {
            throw new \InvalidArgumentException("Invalid binding ID [$id]");
        }
    }

    /**
     * @inheritDoc
     */
    public function bind(string $id, array $definition): void
    {
        $this->assertValidId($id);
        $this->bindings[$id] = $definition;
    }

    /**
     * @inheritDoc
     */
    public function unbind(string $id): bool
    {
        $existed = isset($this->bindings[$id]);
        unset($this->bindings[$id], $this->decorators[$id], $this->strictTypes[$id], $this->expiry[$id]);
        $this->untag($id); // Hapus semua tag yang terkait
        return $existed;
    }

    /**
     * @inheritDoc
     */
    public function getBinding(string $id): ?array
    {
        return $this->bindings[$this->resolveAlias($id)] ?? null;
    }

    /**
     * @inheritDoc
     */
    public function hasBinding(string $id): bool
    {
        return isset($this->bindings[$this->resolveAlias($id)]);
    }

    /**
     * @inheritDoc
     */
    public function resolveAlias(string $id): string
    {
        $seen = [];
        while (isset($this->aliases[$id])) {
            if (isset($seen[$id])) {
                throw new CircularDependencyException("Circular alias detected for: $id");
            }
            $seen[$id] = true;
            $id = $this->aliases[$id];
        }
        return $id;
    }

    /**
     * @inheritDoc
     */
    public function alias(string $id, string $target): void
    {
        $this->assertValidId($id);
        $this->assertValidId($target);
        $this->aliases[$id] = $target;
    }

    /**
     * @inheritDoc
     */
    public function removeAlias(string $alias): bool
    {
        $existed = isset($this->aliases[$alias]);
        unset($this->aliases[$alias], $this->decorators[$alias], $this->strictTypes[$alias], $this->expiry[$alias]);
        $this->untag($alias); // Hapus semua tag yang terkait
        return $existed;
    }

    /**
     * @inheritDoc
     */
    public function tag(string $id, string $tag): void
    {
        $this->assertValidId($id);
        if (!isset($this->tags[$tag])) {
            $this->tags[$tag] = [];
        }
        $this->tags[$tag][$id] = true;
    }

    /**
     * @inheritDoc
     */
    public function untag(string $id, ?string $tag = null): void
    {
        if ($tag !== null) {
            if (isset($this->tags[$tag][$id])) {
                unset($this->tags[$tag][$id]);
                if (empty($this->tags[$tag])) {
                    unset($this->tags[$tag]);
                }
            }
        } else {
            foreach ($this->tags as $tagName => &$ids) {
                if (isset($ids[$id])) {
                    unset($ids[$id]);
                    if (empty($ids)) {
                        unset($this->tags[$tagName]);
                    }
                }
            }
        }
    }

    /**
     * @inheritDoc
     */
    public function addDecorator(string $id, callable $decorator): void
    {
        $this->decorators[$id][] = $decorator;
    }

    /**
     * @inheritDoc
     */
    public function getDecorators(string $id): array
    {
        return $this->decorators[$this->resolveAlias($id)] ?? [];
    }

    /**
     * @inheritDoc
     */
    public function getByTag(string $tag): array
    {
        return array_keys($this->tags[$tag] ?? []);
    }

    /**
     * @inheritDoc
     */
    public function setStrictType(string $id, string $type): void
    {
        $this->strictTypes[$id] = $type;
    }

    /**
     * @inheritDoc
     */
    public function getStrictType(string $id): ?string
    {
        return $this->strictTypes[$id] ?? null;
    }

    /**
     * @inheritDoc
     */
    public function setExpiry(string $id, int $ttl, bool $sliding = false): void
    {
        $this->assertValidId($id);
        $this->expiry[$id] = ['expire_at' => time() + $ttl, 'ttl' => $ttl, 'sliding' => $sliding];
    }

    /**
     * @inheritDoc
     */
    public function getExpiry(string $id): ?array
    {
        return $this->expiry[$id] ?? null;
    }

    /**
     * @inheritDoc
     */
    public function extendExpiryIfSliding(string $id): void
    {
        if (isset($this->expiry[$id]) && !empty($this->expiry[$id]['sliding'])) {
            $this->expiry[$id]['expire_at'] = time() + $this->expiry[$id]['ttl'];
        }
    }

    /**
     * @inheritDoc
     */
    public function checkExpiry(string $id): bool
    {
        if (isset($this->expiry[$id]) && time() > $this->expiry[$id]['expire_at']) {
            unset($this->bindings[$id], $this->expiry[$id], $this->decorators[$id], $this->strictTypes[$id]);
            $this->untag($id); // Hapus semua tag yang terkait
            return true;
        }
        return false;
    }

    /**
     * @inheritDoc
     */
    public function getAllBindings(): array
    {
        return $this->bindings;
    }

    /**
     * @inheritDoc
     */
    public function setAllBindings(array $bindings): void
    {
        $this->bindings = $bindings;
    }

    /**
     * @inheritDoc
     */
    public function getAllAliases(): array
    {
        return $this->aliases;
    }

    /**
     * @inheritDoc
     */
    public function setAllAliases(array $aliases): void
    {
        $this->aliases = $aliases;
    }

    /**
     * @inheritDoc
     */
    public function getAllTags(): array
    {
        return $this->tags;
    }

    /**
     * @inheritDoc
     */
    public function setAllTags(array $tags): void
    {
        $this->tags = $tags;
    }

    /**
     * @inheritDoc
     */
    public function getAllStrictTypes(): array
    {
        return $this->strictTypes;
    }

    /**
     * @inheritDoc
     */
    public function setAllStrictTypes(array $strictTypes): void
    {
        $this->strictTypes = $strictTypes;
    }

    /**
     * @inheritDoc
     */
    public function getAllExpiry(): array
    {
        return $this->expiry;
    }

    /**
     * @inheritDoc
     */
    public function setAllExpiry(array $expiry): void
    {
        $this->expiry = $expiry;
    }
}

