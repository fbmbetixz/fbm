<?php

namespace Core\Container\Attributes;

use Attribute;

/**
 * Atribut ini digunakan untuk menandai metode publik (setter) yang harus dipanggil
 * oleh kontainer setelah instance dibuat, dengan dependensi yang diinjeksi secara otomatis.
 *
 * Contoh penggunaan:
 * `#[SetterInject] public function setLogger(LoggerInterface $logger) { ... }`
 *
 * @package Core\Container\Attributes
 * @Annotation
 * @Target({"METHOD"})
 */
#[Attribute(Attribute::TARGET_METHOD)]
final class SetterInject {}

