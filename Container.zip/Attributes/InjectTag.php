<?php

namespace Core\Container\Attributes;

use Attribute;

/**
 * Atribut ini digunakan untuk menandai parameter konstruktor atau metode
 * yang harus diinjeksi dengan koleksi layanan yang memiliki tag tertentu.
 *
 * Contoh penggunaan:
 * `#[InjectTag('logger.channels')] iterable $loggers`
 *
 * @package Core\Container\Attributes
 * @Annotation
 * @Target({"PARAMETER"})
 */
#[Attribute(Attribute::TARGET_PARAMETER)]
final class InjectTag
{
    /**
     * @param string $tag Tag layanan yang akan diinjeksi.
     */
    public function __construct(public string $tag) {}
}

