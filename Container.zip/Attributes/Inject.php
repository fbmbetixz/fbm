<?php

namespace Core\Container\Attributes;

use Attribute;

/**
 * Atribut ini digunakan untuk menandai parameter konstruktor atau metode
 * yang harus diinjeksi dengan layanan dari kontainer berdasarkan ID tertentu.
 *
 * Contoh penggunaan:
 * `#[Inject('my.service.id')] $myService`
 *
 * @package Core\Container\Attributes
 * @Annotation
 * @Target({"PARAMETER"})
 */
#[Attribute(Attribute::TARGET_PARAMETER)]
final class Inject
{
    /**
     * @param string $id ID layanan yang akan diinjeksi.
     */
    public function __construct(public string $id) {}
}

