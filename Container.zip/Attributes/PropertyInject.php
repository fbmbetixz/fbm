<?php

namespace Core\Container\Attributes;

use Attribute;

/**
 * Atribut ini digunakan untuk menandai properti publik yang harus diinjeksi
 * dengan layanan dari kontainer berdasarkan ID tertentu setelah instance dibuat.
 *
 * Contoh penggunaan:
 * `#[PropertyInject('config.repository')] public ConfigRepository $config;`
 *
 * @package Core\Container\Attributes
 * @Annotation
 * @Target({"PROPERTY"})
 */
#[Attribute(Attribute::TARGET_PROPERTY)]
final class PropertyInject
{
    /**
     * @param string $id ID layanan yang akan diinjeksi ke properti.
     */
    public function __construct(public string $id) {}
}

