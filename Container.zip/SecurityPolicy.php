<?php

namespace Core\Container;

/**
 * Kebijakan keamanan untuk kontainer yang mengontrol namespace terpercaya
 * dan izin untuk closure anonim. Ini membantu mencegah injeksi kode yang tidak diinginkan.
 *
 * @package Core\Container
 */
class SecurityPolicy
{
    /**
     * @var string[] Daftar namespace yang dianggap tepercaya.
     */
    private array $trustedNamespaces = [];

    /**
     * @var bool Menentukan apakah closure anonim diizinkan sebagai factory.
     */
    private bool $allowAnonymousClosures = false;

    /**
     * Menambahkan namespace tepercaya ke daftar.
     *
     * @param string $namespace Namespace yang akan ditambahkan (misalnya, 'App\Services').
     * @return $this
     */
    public function addTrustedNamespace(string $namespace): self
    {
        $this->trustedNamespaces[] = rtrim($namespace, '\\') . '\\';
        return $this;
    }

    /**
     * Mengatur apakah closure anonim diizinkan sebagai factory.
     *
     * @param bool $allow True untuk mengizinkan, false untuk melarang (default).
     * @return $this
     */
    public function allowAnonymousClosures(bool $allow = true): self
    {
        $this->allowAnonymousClosures = $allow;
        return $this;
    }

    /**
     * Memeriksa apakah callable atau string yang diberikan dianggap tepercaya
     * berdasarkan kebijakan keamanan yang dikonfigurasi.
     *
     * @param callable|string $callable Callable atau nama kelas/metode.
     * @return bool True jika tepercaya, false jika tidak.
     */
    public function isTrusted(callable|string $callable): bool
    {
        if ($callable instanceof \Closure) {
            return $this->allowAnonymousClosures;
        }

        $className = null;

        // Handle 'ClassName::methodName' string format
        if (is_string($callable) && str_contains($callable, '::')) {
            $callable = explode('::', $callable);
        }

        if (is_array($callable) && isset($callable[0]) && is_string($callable[0])) {
            $className = $callable[0];
        } elseif (is_string($callable) && class_exists($callable)) {
            $className = $callable;
        } elseif (is_object($callable) && !($callable instanceof \Closure)) {
            $className = get_class($callable);
        }

        if ($className === null) {
            return false; // Not a class-based callable or unsupported format
        }

        foreach ($this->trustedNamespaces as $ns) {
            if (str_starts_with($className, $ns)) {
                return true;
            }
        }

        return false;
    }
}

