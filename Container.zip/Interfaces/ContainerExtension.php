<?php

namespace Core\Container\Interfaces;

use Core\Container\ContainerBuilder;
use Core\Container\NextLevelContainer;

/**
 * Antarmuka untuk ekstensi kontainer yang memungkinkan penambahan fungsionalitas
 * ke kontainer selama pendaftaran dan siklus hidup resolusi.
 *
 * @package Core\Container\Interfaces
 */
interface ContainerExtension
{
    /**
     * Mendaftarkan fungsionalitas ekstensi ke kontainer dan builder.
     * Dipanggil selama proses build kontainer.
     *
     * @param NextLevelContainer $container Instance kontainer yang sedang dibangun.
     * @param ContainerBuilder $builder Instance builder kontainer.
     * @return void
     */
    public function register(NextLevelContainer $container, ContainerBuilder $builder): void;

    /**
     * Hook yang dipanggil sebelum layanan diselesaikan.
     *
     * @param string $id ID layanan yang akan diselesaikan.
     * @param NextLevelContainer $container Instance kontainer.
     * @return void
     */
    public function beforeResolve(string $id, NextLevelContainer $container): void;

    /**
     * Hook yang dipanggil setelah layanan berhasil diselesaikan.
     *
     * @param string $id ID layanan yang diselesaikan.
     * @param mixed $instance Instance layanan yang diselesaikan.
     * @param NextLevelContainer $container Instance kontainer.
     * @return void
     */
    public function afterResolve(string $id, mixed $instance, NextLevelContainer $container): void;
}

