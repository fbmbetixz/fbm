<?php

namespace Core\Container\Interfaces;

use Core\Container\NextLevelContainer;

/**
 * Antarmuka untuk manajer snapshot yang memungkinkan ekspor, impor, dan diff
 * status kontainer atau tenant.
 *
 * @package Core\Container\Interfaces
 */
interface SnapshotManager
{
    /**
     * Mengekspor status sebagai string JSON atau ke file.
     *
     * @param array $state Status yang akan diekspor.
     * @param string|null $file Path file untuk menyimpan snapshot.
     * @return string|null String JSON dari status, atau null jika disimpan ke file.
     */
    public function export(array $state, ?string $file = null): ?string;

    /**
     * Mengimpor status dari string JSON atau file.
     *
     * @param string|array $data String JSON, path file, atau array data.
     * @return array Data yang diimpor.
     */
    public function import(string|array $data): array;

    /**
     * Membandingkan dua array status dan mengembalikan perbedaannya.
     *
     * @param array $a Array status pertama.
     * @param array $b Array status kedua.
     * @return array Array yang menunjukkan perbedaan (added, removed, changed).
     */
    public function diff(array $a, array $b): array;

    /**
     * Mengekspor snapshot dari kontainer tenant.
     *
     * @param array $tenants Array tenant (ID tenant => instance NextLevelContainer).
     * @return array Array asosiatif dari ID tenant ke array snapshotnya.
     */
    public function exportTenants(array $tenants): array;

    /**
     * Mengimpor snapshot tenant.
     *
     * @param array $snaps Array snapshot tenant (ID tenant => array snapshot).
     * @param callable $factory Callable yang membuat instance kontainer baru untuk setiap tenant.
     * @return array Array tenant yang diimpor (ID tenant => instance NextLevelContainer).
     */
    public function importTenants(array $snaps, callable $factory): array;
}

