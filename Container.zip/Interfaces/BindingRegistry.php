<?php

namespace Core\Container\Interfaces;

use Core\Container\Exceptions\CircularDependencyException;

/**
 * Antarmuka untuk registri binding yang bertanggung jawab untuk menyimpan dan mengelola
 * semua definisi layanan, alias, tag, dekorator, tipe ketat, dan pengaturan kadaluarsa.
 *
 * @package Core\Container\Interfaces
 */
interface BindingRegistry
{
    /**
     * Mengikat ID layanan ke definisi layanan.
     *
     * @param string $id ID unik layanan.
     * @param array $definition Definisi layanan, biasanya berisi 'factory' dan 'options'.
     * @return void
     */
    public function bind(string $id, array $definition): void;

    /**
     * Melepaskan binding layanan dari registri.
     *
     * @param string $id ID layanan yang akan dilepaskan.
     * @return bool True jika binding berhasil dilepaskan, false jika tidak ditemukan.
     */
    public function unbind(string $id): bool;

    /**
     * Mengambil definisi binding untuk ID layanan tertentu.
     *
     * @param string $id ID layanan.
     * @return array|null Definisi binding atau null jika tidak ditemukan.
     */
    public function getBinding(string $id): ?array;

    /**
     * Memeriksa apakah ID layanan memiliki binding dalam registri.
     *
     * @param string $id ID layanan.
     * @return bool True jika binding ada, false jika tidak.
     */
    public function hasBinding(string $id): bool;

    /**
     * Menyelesaikan alias ID layanan ke ID target yang sebenarnya.
     * Mencegah alias melingkar.
     *
     * @param string $id ID layanan atau alias.
     * @return string ID target yang sebenarnya.
     * @throws CircularDependencyException Jika alias melingkar terdeteksi.
     */
    public function resolveAlias(string $id): string;

    /**
     * Mengambil semua ID layanan yang terkait dengan tag tertentu.
     *
     * @param string $tag Nama tag.
     * @return string[] Array dari ID layanan yang memiliki tag ini.
     */
    public function getByTag(string $tag): array;

    /**
     * Membuat alias untuk layanan.
     *
     * @param string $id Alias yang akan dibuat.
     * @param string $target ID layanan target.
     * @return void
     */
    public function alias(string $id, string $target): void;

    /**
     * Menghapus alias yang ada.
     *
     * @param string $alias Alias yang akan dihapus.
     * @return bool True jika alias berhasil dihapus, false jika tidak ditemukan.
     */
    public function removeAlias(string $alias): bool;

    /**
     * Menandai layanan dengan tag tertentu.
     *
     * @param string $id ID layanan.
     * @param string $tag Nama tag.
     * @return void
     */
    public function tag(string $id, string $tag): void;

    /**
     * Menghapus tag dari layanan.
     * Jika $tag adalah null, semua tag untuk layanan akan dihapus.
     *
     * @param string $id ID layanan.
     * @param string|null $tag Nama tag yang akan dihapus.
     * @return void
     */
    public function untag(string $id, ?string $tag = null): void;

    /**
     * Menambahkan dekorator ke layanan.
     *
     * @param string $id ID layanan.
     * @param callable $decorator Callable yang menerima instance layanan dan kontainer, mengembalikan instance yang didekorasi.
     * @return void
     */
    public function addDecorator(string $id, callable $decorator): void;

    /**
     * Mengambil semua dekorator untuk layanan tertentu.
     *
     * @param string $id ID layanan.
     * @return callable[] Array dari dekorator.
     */
    public function getDecorators(string $id): array;

    /**
     * Menetapkan tipe ketat yang harus diimplementasikan atau diwarisi oleh layanan.
     *
     * @param string $id ID layanan.
     * @param string $type Nama kelas atau antarmuka.
     * @return void
     */
    public function setStrictType(string $id, string $type): void;

    /**
     * Mengambil tipe ketat yang ditetapkan untuk layanan.
     *
     * @param string $id ID layanan.
     * @return string|null Nama kelas atau antarmuka, atau null jika tidak ada.
     */
    public function getStrictType(string $id): ?string;

    /**
     * Mengatur waktu kedaluarsa untuk layanan.
     *
     * @param string $id ID layanan.
     * @param int $ttl Waktu hidup (Time To Live) dalam detik.
     * @param bool $sliding Jika true, waktu kedaluarsa diperpanjang setiap kali layanan diakses.
     * @return void
     */
    public function setExpiry(string $id, int $ttl, bool $sliding): void;

    /**
     * Mengambil pengaturan kedaluarsa untuk layanan.
     *
     * @param string $id ID layanan.
     * @return array|null Array berisi 'expire_at', 'ttl', dan 'sliding', atau null jika tidak ada.
     */
    public function getExpiry(string $id): ?array;

    /**
     * Memperpanjang waktu kedaluarsa layanan jika diatur sebagai sliding.
     *
     * @param string $id ID layanan.
     * @return void
     */
    public function extendExpiryIfSliding(string $id): void;

    /**
     * Memeriksa apakah layanan telah kedaluarsa dan menghapusnya jika demikian.
     *
     * @param string $id ID layanan.
     * @return bool True jika layanan telah kedaluarsa dan dihapus, false jika tidak.
     */
    public function checkExpiry(string $id): bool;

    /**
     * Mengambil semua binding yang terdaftar.
     *
     * @return array Semua definisi binding.
     */
    public function getAllBindings(): array;

    /**
     * Menetapkan semua binding.
     * Berguna untuk snapshotting/restorasi.
     *
     * @param array $bindings Array binding.
     * @return void
     */
    public function setAllBindings(array $bindings): void;

    /**
     * Mengambil semua alias yang terdaftar.
     *
     * @return array Semua alias.
     */
    public function getAllAliases(): array;

    /**
     * Menetapkan semua alias.
     *
     * @param array $aliases Array alias.
     * @return void
     */
    public function setAllAliases(array $aliases): void;

    /**
     * Mengambil semua tag yang terdaftar.
     *
     * @return array Semua tag.
     */
    public function getAllTags(): array;

    /**
     * Menetapkan semua tag.
     *
     * @param array $tags Array tag.
     * @return void
     */
    public function setAllTags(array $tags): void;

    /**
     * Mengambil semua tipe ketat yang terdaftar.
     *
     * @return array Semua tipe ketat.
     */
    public function getAllStrictTypes(): array;

    /**
     * Menetapkan semua tipe ketat.
     *
     * @param array $strictTypes Array tipe ketat.
     * @return void
     */
    public function setAllStrictTypes(array $strictTypes): void;

    /**
     * Mengambil semua pengaturan kedaluarsa yang terdaftar.
     *
     * @return array Semua pengaturan kedaluarsa.
     */
    public function getAllExpiry(): array;

    /**
     * Menetapkan semua pengaturan kedaluarsa.
     *
     * @param array $expiry Array pengaturan kedaluarsa.
     * @return void
     */
    public function setAllExpiry(array $expiry): void;
}