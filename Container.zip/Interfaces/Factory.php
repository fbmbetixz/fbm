<?php

namespace Core\Container\Interfaces;

use Psr\Container\ContainerInterface;

/**
 * Antarmuka penanda untuk pabrik (factory) yang dapat digunakan sebagai callable
 * untuk membuat instance layanan.
 *
 * @package Core\Container\Interfaces
 */
interface Factory
{
    /**
     * Metode yang akan dipanggil oleh kontainer untuk membuat instance layanan.
     *
     * @param ContainerInterface $container Instance kontainer.
     * @return mixed Instance layanan yang dibuat.
     */
    public function __invoke(ContainerInterface $container): mixed;
}

