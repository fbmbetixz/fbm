<?php

namespace Core\Container\Interfaces;

use Core\Container\Exceptions\ArchitecturalViolationException;

/**
 * Antarmuka untuk aturan arsitektur yang dapat digunakan untuk memvalidasi
 * binding kontainer.
 *
 * @package Core\Container\Interfaces
 */
interface ArchitecturalRule
{
    /**
     * Memvalidasi binding layanan tunggal terhadap aturan arsitektur.
     *
     * @param string $id ID layanan yang sedang divalidasi.
     * @param array $binding Definisi binding layanan.
     * @param array $allBindings Semua definisi binding yang terdaftar di kontainer.
     * @return void
     * @throws ArchitecturalViolationException Jika aturan arsitektur dilanggar.
     */
    public function validate(string $id, array $binding, array $allBindings): void;
}

