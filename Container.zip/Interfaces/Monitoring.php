<?php

namespace Core\Container\Interfaces;

use Core\Container\NextLevelContainer;

/**
 * Antarmuka untuk sistem monitoring yang melacak metrik resolusi layanan
 * dan menyediakan pemeriksaan kesehatan.
 *
 * @package Core\Container\Interfaces
 */
interface Monitoring
{
    /**
     * Mencatat data resolusi untuk layanan.
     *
     * @param string $id ID layanan yang diselesaikan.
     * @param float $start Waktu mulai resolusi (microtime(true)).
     * @param bool $success Status keberhasilan resolusi.
     * @param float $startMemory Penggunaan memori pada awal resolusi.
     * @return void
     */
    public function recordResolve(string $id, float $start, bool $success, float $startMemory): void;

    /**
     * Menetapkan probe healthcheck untuk layanan tertentu.
     *
     * @param string $id ID layanan.
     * @param callable $probe Callable yang melakukan pemeriksaan kesehatan. Harus mengembalikan boolean.
     * @return void
     */
    public function setHealthcheck(string $id, callable $probe): void;

    /**
     * Melakukan pemeriksaan kesehatan untuk instance layanan.
     *
     * @param string $id ID layanan.
     * @param mixed $instance Instance layanan yang akan diperiksa.
     * @return bool True jika layanan sehat, false jika tidak.
     */
    public function checkHealth(string $id, mixed $instance): bool;

    /**
     * Menambahkan pusher metrik khusus yang akan dipanggil saat metrik resolusi diperbarui.
     *
     * @param callable $cb Callback yang akan menerima ID layanan dan statistik resolusi.
     * @return void
     */
    public function addMetricsPusher(callable $cb): void;

    /**
     * Mendump semua statistik resolusi layanan.
     *
     * @param string|null $sort Kunci untuk mengurutkan hasil (misalnya, 'total_time', 'count').
     * @return array Semua statistik resolusi.
     */
    public function dumpResolveStats(string $sort = null): array;

    /**
     * Mengambil statistik resolusi untuk layanan tertentu.
     *
     * @param string $id ID layanan.
     * @return array Statistik resolusi (count, total_time, avg_time, last_time, failures).
     */
    public function getResolveStats(string $id): array;

    /**
     * Mengambil log diagnostik resolusi layanan.
     *
     * @return array Log resolusi, berisi detail seperti ID, waktu, dan memori.
     */
    public function getDiagnostics(): array;

    /**
     * Membersihkan log diagnostik resolusi layanan.
     *
     * @return void
     */
    public function clearDiagnostics(): void;
}

