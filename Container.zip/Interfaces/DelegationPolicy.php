<?php

namespace Core\Container\Interfaces;

use Psr\Container\ContainerInterface;

/**
 * Antarmuka untuk kebijakan delegasi yang menentukan apakah kontainer anak
 * dapat mendelegasikan resolusi layanan ke kontainer induknya.
 *
 * @package Core\Container\Interfaces
 */
interface DelegationPolicy
{
    /**
     * Menentukan apakah resolusi layanan dengan ID tertentu dapat didelegasikan
     * dari kontainer anak ke kontainer induk.
     *
     * @param string $id ID layanan yang akan diselesaikan.
     * @param ContainerInterface $child Kontainer anak yang mencoba menyelesaikan.
     * @param ContainerInterface $parent Kontainer induk yang mungkin mendelegasikan.
     * @return bool True jika delegasi diizinkan, false jika tidak.
     */
    public function canDelegate(string $id, ContainerInterface $child, ContainerInterface $parent): bool;
}

