<?php

namespace Core\Container\Interfaces;

/**
 * Antarmuka untuk manajer rahasia yang menyediakan cara aman untuk mengikat
 * dan mengambil nilai rahasia (misalnya, kunci API, kredensial database)
 * tanpa menyimpannya langsung di kontainer.
 *
 * @package Core\Container\Interfaces
 */
interface SecretManager
{
    /**
     * Mengikat ID rahasia ke kunci dan provider yang akan mengambil nilai rahasia.
     *
     * @param string $id ID unik untuk rahasia.
     * @param string $key Kunci yang akan digunakan oleh provider (misalnya, nama variabel lingkungan).
     * @param callable $provider Callable yang menerima kunci dan mengembalikan nilai rahasia.
     * @return void
     */
    public function bindSecret(string $id, string $key, callable $provider): void;

    /**
     * Mengambil nilai rahasia untuk ID tertentu.
     *
     * @param string $id ID rahasia.
     * @return mixed Nilai rahasia, atau null jika tidak ditemukan atau terjadi kesalahan.
     */
    public function getSecret(string $id): mixed;

    /**
     * Memeriksa apakah rahasia dengan ID tertentu telah terikat.
     *
     * @param string $id ID rahasia.
     * @return bool True jika rahasia terikat, false jika tidak.
     */
    public function hasSecret(string $id): bool;
}

