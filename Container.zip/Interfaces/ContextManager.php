<?php

namespace Core\Container\Interfaces;

use Psr\Container\ContainerInterface;
use Core\Container\NextLevelContainer;

/**
 * Antarmuka untuk manajer konteks yang mengelola stack konteks,
 * binding dinamis, dan instance tenant.
 *
 * @package Core\Container\Interfaces
 */
interface ContextManager
{
    /**
     * Mendorong konteks baru ke dalam stack konteks.
     *
     * @param array $ctx Array asosiatif yang mewakili konteks.
     * @return void
     */
    public function push(array $ctx): void;

    /**
     * Mengeluarkan konteks dari stack konteks.
     *
     * @return void
     */
    public function pop(): void;

    /**
     * Mengambil konteks teratas dari stack.
     *
     * @return array Konteks saat ini, atau array kosong jika stack kosong.
     */
    public function current(): array;

    /**
     * Mengikat binding dinamis yang resolusinya bergantung pada konteks saat ini.
     *
     * @param string $id ID unik untuk binding dinamis.
     * @param callable $resolver Callable yang menerima array konteks dan instance kontainer, mengembalikan layanan.
     * @return void
     */
    public function bindDynamic(string $id, callable $resolver): void;

    /**
     * Menyelesaikan binding dinamis berdasarkan konteks saat ini.
     *
     * @param string $id ID binding dinamis.
     * @param ContainerInterface $container Instance kontainer yang melakukan resolusi.
     * @return mixed Nilai yang diselesaikan, atau null jika tidak dapat diselesaikan.
     */
    public function resolveDynamic(string $id, ContainerInterface $container): mixed;

    /**
     * Mengelola instance kontainer untuk tenant tertentu.
     * Jika instance untuk tenant belum ada, factory akan dipanggil untuk membuatnya.
     *
     * @param string $tenantId ID unik tenant.
     * @param callable $factory Callable yang mengembalikan instance kontainer untuk tenant.
     * @return mixed Instance kontainer atau objek lain yang terkait dengan tenant.
     */
    public function forTenant(string $tenantId, callable $factory): mixed;

    /**
     * Mengambil semua instance tenant yang dikelola.
     *
     * @return array Array asosiatif dari ID tenant ke instance tenant.
     */
    public function getTenants(): array;

    /**
     * Menetapkan semua instance tenant. Berguna untuk snapshotting/restorasi.
     *
     * @param array $tenants Array tenant.
     * @return void
     */
    public function setTenants(array $tenants): void;
}

