<?php

namespace Core\Container\Interfaces;

/**
 * Antarmuka penanda untuk layanan yang memerlukan pembersihan sumber daya
 * ketika kontainer dimatikan atau cakupan direset.
 *
 * @package Core\Container\Interfaces
 */
interface Disposable
{
    /**
     * Melakukan pembersihan sumber daya yang diperlukan oleh layanan.
     *
     * @return void
     */
    public function dispose(): void;
}

