<?php

namespace Core\Container\Interfaces;

/**
 * Antarmuka untuk generator dokumentasi yang dapat menghasilkan
 * representasi binding kontainer.
 *
 * @package Core\Container\Interfaces
 */
interface DocGenerator
{
    /**
     * Menghasilkan dokumentasi dari binding dan tag kontainer.
     *
     * @param array $bindings Array semua definisi binding.
     * @param array $tags Array semua tag.
     * @param string $format Format output (misalnya, 'markdown', 'json').
     * @return string Dokumentasi yang dihasilkan.
     */
    public function generate(array $bindings, array $tags = [], string $format = 'markdown'): string;
}

