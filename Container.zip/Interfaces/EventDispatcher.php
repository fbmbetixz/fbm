<?php

namespace Core\Container\Interfaces;

/**
 * Antarmuka untuk dispatcher peristiwa yang memungkinkan komponen kontainer
 * untuk menerbitkan dan mendengarkan peristiwa.
 *
 * @package Core\Container\Interfaces
 */
interface EventDispatcher
{
    /**
     * Mendaftarkan listener untuk event tertentu.
     *
     * @param string $event Nama event.
     * @param callable $cb Callable yang akan dipanggil ketika event terjadi.
     * @return void
     */
    public function on(string $event, callable $cb): void;

    /**
     * Memicu event, memanggil semua listener yang terdaftar untuk event tersebut.
     *
     * @param string $event Nama event yang akan dipicu.
     * @param mixed ...$args Argumen yang akan diteruskan ke listener.
     * @return array Hasil dari pemanggilan listener.
     */
    public function fire(string $event, ...$args): array;
}

