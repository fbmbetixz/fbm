<?php

namespace Core\Container;

use Core\Container\Interfaces\Monitoring;

/**
 * Implementasi default dari Monitoring.
 * Melacak statistik resolusi layanan, mendukung healthcheck, dan pusher metrik.
 *
 * @package Core\Container
 * @implements Monitoring
 */
class DefaultMonitoring implements Monitoring
{
    /**
     * @var array<string, array{count: int, total_time: float, avg_time: float, last_time: float|null, failures: int}> Statistik resolusi per ID layanan.
     */
    private array $resolveStats = [];

    /**
     * @var array<string, callable> Probe healthcheck per ID layanan.
     */
    private array $healthchecks = [];

    /**
     * @var callable[] Daftar callable untuk mendorong metrik.
     */
    private array $metricsPushers = [];

    /**
     * @var array<array{id: string, time_ms: float, memory_kb: float}> Log diagnostik resolusi layanan.
     */
    private array $resolutionLog = [];

    /**
     * @inheritDoc
     */
    public function recordResolve(string $id, float $start, bool $success, float $startMemory): void
    {
        $elapsed = microtime(true) - $start;
        if (!isset($this->resolveStats[$id])) {
            $this->resolveStats[$id] = ['count' => 0, 'total_time' => 0, 'avg_time' => 0, 'last_time' => null, 'failures' => 0];
        }

        $this->resolveStats[$id]['count']++;
        $this->resolveStats[$id]['total_time'] += $elapsed;
        $this->resolveStats[$id]['avg_time'] = $this->resolveStats[$id]['total_time'] / $this->resolveStats[$id]['count'];
        $this->resolveStats[$id]['last_time'] = $elapsed;
        if (!$success) {
            $this->resolveStats[$id]['failures']++;
        }

        $this->pushMetrics($id, $this->resolveStats[$id]);
        $this->resolutionLog[] = [
            'id' => $id,
            'time_ms' => $elapsed * 1000, // Waktu dalam milidetik
            'memory_kb' => (memory_get_usage() - $startMemory) / 1024 // Perubahan memori dalam KB
        ];
    }

    /**
     * @inheritDoc
     */
    public function setHealthcheck(string $id, callable $probe): void
    {
        $this->healthchecks[$id] = $probe;
    }

    /**
     * @inheritDoc
     */
    public function checkHealth(string $id, mixed $instance): bool
    {
        try {
            return !isset($this->healthchecks[$id]) || (bool)call_user_func($this->healthchecks[$id], $instance);
        } catch (\Throwable $e) {
            // Log the healthcheck failure if a logger is available
            return false;
        }
    }

    /**
     * @inheritDoc
     */
    public function addMetricsPusher(callable $cb): void
    {
        $this->metricsPushers[] = $cb;
    }

    /**
     * Mendorong metrik ke semua pusher yang terdaftar.
     *
     * @param string $id ID layanan.
     * @param array $stats Statistik resolusi layanan.
     * @return void
     */
    private function pushMetrics(string $id, array $stats): void
    {
        foreach ($this->metricsPushers as $cb) {
            $cb($id, $stats);
        }
    }

    /**
     * @inheritDoc
     */
    public function dumpResolveStats(string $sort = null): array
    {
        $stats = $this->resolveStats;
        if ($sort && isset(reset($stats)[$sort])) {
            uasort($stats, fn($a, $b) => $b[$sort] <=> $a[$sort]);
        }
        return $stats;
    }

    /**
     * @inheritDoc
     */
    public function getResolveStats(string $id): array
    {
        return $this->resolveStats[$id] ?? ['count' => 0, 'total_time' => 0, 'avg_time' => 0, 'last_time' => null, 'failures' => 0];
    }

    /**
     * @inheritDoc
     */
    public function getDiagnostics(): array
    {
        return $this->resolutionLog;
    }

    /**
     * @inheritDoc
     */
    public function clearDiagnostics(): void
    {
        $this->resolutionLog = [];
    }
}

