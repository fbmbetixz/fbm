<?php

namespace Core\Container;

use Core\Container\Interfaces\ArchitecturalRule;
use Core\Container\Exceptions\ContainerException;

/**
 * Validator yang menerapkan serangkaian ArchitecturalRule pada semua binding kontainer.
 *
 * @package Core\Container
 */
class RuleValidator
{
    /**
     * @var ArchitecturalRule[] Daftar aturan arsitektur yang akan diterapkan.
     */
    public function __construct(private array $rules) {}

    /**
     * Memvalidasi semua binding yang diberikan terhadap semua aturan yang terdaftar.
     *
     * @param array $bindings Semua definisi binding dari registri.
     * @return void
     * @throws ContainerException Jika ada aturan arsitektur yang dilanggar.
     */
    public function validateAll(array $bindings): void
    {
        foreach ($this->rules as $rule) {
            foreach ($bindings as $id => $binding) {
                // Setiap aturan bertanggung jawab untuk melemparkan pengecualiannya sendiri
                // jika ada pelanggaran.
                $rule->validate($id, $binding, $bindings);
            }
        }
    }
}

