<?php

namespace Core\Container;

use Core\Container\Interfaces\DocGenerator;

/**
 * Implementasi default dari DocGenerator.
 * Menghasilkan dokumentasi dasar untuk binding kontainer dalam format Markdown atau JSON.
 *
 * @package Core\Container
 * @implements DocGenerator
 */
class DefaultDocGenerator implements DocGenerator
{
    /**
     * @inheritDoc
     */
    public function generate(array $bindings, array $tags = [], string $format = 'markdown'): string
    {
        $lines = [];
        foreach ($bindings as $id => $b) {
            // Escape Markdown special characters in ID
            $idEsc = str_replace(['*', '_'], ['\\*', '\\_'], $id);

            $associatedTags = [];
            foreach ($tags as $tagName => $idsInTag) {
                if (isset($idsInTag[$id])) {
                    $associatedTags[] = $tagName;
                }
            }
            $tagStr = implode(', ', $associatedTags);

            $lines[] = "- **{$idEsc}**" . ($tagStr ? " _(tags: {$tagStr})_" : "");
        }

        if ($format === 'markdown') {
            return implode("\n", $lines);
        } elseif ($format === 'json') {
            return json_encode($lines, JSON_PRETTY_PRINT);
        }
        // Default ke markdown jika format tidak dikenal
        return implode("\n", $lines);
    }
}

