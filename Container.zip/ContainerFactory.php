<?php

namespace Core\Container;

use Psr\Container\ContainerInterface;
use Psr\Log\LoggerInterface;
use Psr\Log\NullLogger;
use Core\Container\Exceptions\ContainerException;
use Core\Container\Interfaces\ArchitecturalRule;
use Core\Container\Interfaces\BindingRegistry;
use Core\Container\Interfaces\ContextManager;
use Core\Container\Interfaces\DelegationPolicy;
use Core\Container\Interfaces\DocGenerator;
use Core\Container\Interfaces\EventDispatcher;
use Core\Container\Interfaces\Monitoring;
use Core\Container\Interfaces\SecretManager;
use ReflectionClass;
use Throwable;

/**
 * ContainerFactory menyediakan metode statis untuk membuat instance NextLevelContainer
 * dari array konfigurasi. Ini adalah titik masuk utama untuk menginisialisasi kontainer.
 *
 * @package Core\Container
 */
class ContainerFactory
{
    /**
     * Membuat instance NextLevelContainer dari array konfigurasi yang diberikan.
     *
     * @param array $config Array konfigurasi untuk kontainer.
     * @param ContainerInterface|null $parentContainer Kontainer induk opsional jika membuat kontainer anak.
     * @return NextLevelContainer Instance kontainer yang telah dikonfigurasi.
     * @throws ContainerException Jika konfigurasi gagal validasi atau ada masalah dalam pembangunan.
     */
    public static function create(array $config, ?ContainerInterface $parentContainer = null): NextLevelContainer
    {
        $builder = new ContainerBuilder();
        $logger = new NullLogger(); // Logger sementara, akan diganti jika dikonfigurasi
        $securityPolicy = new SecurityPolicy();

        $coreSettings = $config['core_settings'] ?? [];

        // Konfigurasi strict overwrite
        $builder->withStrictOverwrite($coreSettings['strict_overwrite'] ?? false);

        // Konfigurasi logger
        if (isset($coreSettings['logger_class']) && class_exists($coreSettings['logger_class'])) {
            try {
                $logger = new $coreSettings['logger_class']();
            } catch (Throwable $e) {
                // Jika logger kustom gagal diinisialisasi, gunakan NullLogger dan log peringatan
                error_log("Failed to initialize custom logger '{$coreSettings['logger_class']}': " . $e->getMessage());
                $logger = new NullLogger();
            }
        }
        $builder->withLogger($logger);

        // Konfigurasi kebijakan keamanan
        $securityConfig = $coreSettings['security_policy'] ?? [];
        foreach ($securityConfig['trusted_namespaces'] ?? [] as $ns) {
            $securityPolicy->addTrustedNamespace($ns);
        }
        if ($securityConfig['allow_anonymous_closures'] ?? false) {
            $securityPolicy->allowAnonymousClosures(true);
        }
        $builder->withSecurityPolicy($securityPolicy);

        // Validasi konfigurasi awal
        $validator = new ConfigValidator($logger);
        if (!$validator->validate($config)) {
            throw new ContainerException("Configuration failed validation. Check logs for details.");
        }

        // Dependensi yang diketahui yang bisa diinjeksikan ke konstruktor manajer
        $knownDeps = ['logger' => $logger];

        // Bangun manajer inti
        $deps = $config['dependencies_implementations'] ?? [];
        self::buildManager($builder, 'withBindingRegistry', $deps['registry'] ?? [], InMemoryBindingRegistry::class, $logger, $knownDeps);
        self::buildManager($builder, 'withMonitoring', $deps['monitoring'] ?? [], DefaultMonitoring::class, $logger, $knownDeps);
        self::buildManager($builder, 'withEventDispatcher', $deps['events'] ?? [], DefaultEventDispatcher::class, $logger, $knownDeps);
        self::buildManager($builder, 'withSnapshotManager', $deps['snapshot_manager'] ?? [], DefaultSnapshotManager::class, $logger, $knownDeps);
        self::buildManager($builder, 'withSecretManager', $deps['secret_manager'] ?? [], DefaultSecretManager::class, $logger, $knownDeps);
        self::buildManager($builder, 'withContextManager', $deps['context_manager'] ?? [], DefaultContextManager::class, $logger, $knownDeps);
        self::buildManager($builder, 'withDocGenerator', $deps['doc_generator'] ?? [], DefaultDocGenerator::class, $logger, $knownDeps);

        // Konfigurasi fitur opsional
        $features = $config['features'] ?? [];

        // Aturan arsitektur
        if (isset($features['architectural_rules']['rules'])) {
            foreach ($features['architectural_rules']['rules'] as $ruleClass) {
                if (class_exists($ruleClass) && is_a($ruleClass, ArchitecturalRule::class, true)) {
                    $builder->withArchitecturalRule(new $ruleClass());
                } else {
                    $logger->warning('Invalid architectural rule class configured: ' . $ruleClass);
                }
            }
        }

        // Kontainer induk dan kebijakan delegasi
        if (($features['parent_container']['enabled'] ?? false) && $parentContainer) {
            $policyClass = $features['parent_container']['delegation_policy_class'] ?? AllowAllPolicy::class;
            if (class_exists($policyClass) && is_a($policyClass, DelegationPolicy::class, true)) {
                try {
                    $builder->withParent($parentContainer, new $policyClass());
                } catch (Throwable $e) {
                    $logger->error("Failed to set parent container with policy '{$policyClass}': " . $e->getMessage());
                }
            } else {
                $logger->warning('Invalid delegation policy class configured: ' . $policyClass);
                // Fallback ke kebijakan default jika kelas tidak valid
                $builder->withParent($parentContainer, new AllowAllPolicy());
            }
        }

        // Bangun kontainer
        $container = $builder->build();

        // Daftarkan definisi layanan, alias, tag, dan dekorator
        $serviceDefinitions = $config['service_definitions'] ?? [];

        foreach ($serviceDefinitions['bindings'] ?? [] as $id => $definition) {
            $factory = $definition['factory'];
            if (!$securityPolicy->isTrusted($factory)) {
                $logger->error("Untrusted factory for binding '{$id}'. Skipping.", ['factory' => $factory]);
                continue;
            }
            $options = $definition['options'] ?? [];

            // Handle kasus di mana 'factory' adalah nilai langsung (array, string, dll)
            // Ubah menjadi closure sederhana yang mengembalikan nilai tersebut.
            if (is_array($factory) && !is_callable($factory)) {
                $value = $factory;
                $factory = fn() => $value;
            }

            try {
                $container->bind($id, $factory, $options);
                if (isset($definition['strict_type'])) {
                    $container->setStrictType($id, $definition['strict_type']);
                }
                if (isset($definition['expiry'])) {
                    $container->setExpiry($id, $definition['expiry']['ttl'] ?? 0, $definition['expiry']['sliding'] ?? false);
                }
                foreach ($definition['tags'] ?? [] as $tag) {
                    $container->tag($id, $tag);
                }
            } catch (Throwable $e) {
                $logger->error("Failed to bind service '{$id}': " . $e->getMessage());
            }
        }

        foreach ($serviceDefinitions['aliases'] ?? [] as $alias => $target) {
            try {
                $container->alias($alias, $target);
            } catch (Throwable $e) {
                $logger->error("Failed to set alias '{$alias}' to '{$target}': " . $e->getMessage());
            }
        }

        // Tagging tambahan yang mungkin tidak terkait langsung dengan binding
        foreach ($serviceDefinitions['tags_only'] ?? [] as $tag => $ids) {
            foreach ($ids as $id) {
                try {
                    $container->tag($id, $tag);
                } catch (Throwable $e) {
                    $logger->warning("Failed to tag '{$id}' with '{$tag}': " . $e->getMessage());
                }
            }
        }

        // Dekorator tambahan
        foreach ($serviceDefinitions['decorators_only'] ?? [] as $id => $decorators) {
            foreach ($decorators as $decorator) {
                if (is_callable($decorator) && $securityPolicy->isTrusted($decorator)) {
                    try {
                        $container->decorate($id, $decorator);
                    } catch (Throwable $e) {
                        $logger->error("Failed to apply decorator to '{$id}': " . $e->getMessage());
                    }
                } else {
                    $logger->warning("Invalid or untrusted decorator for '{$id}'. Skipping.", ['decorator' => $decorator]);
                }
            }
        }

        // Segel kontainer jika diatur untuk produksi
        if ($coreSettings['seal_in_production'] ?? false) {
            $container->seal();
        }

        return $container;
    }

    /**
     * Metode pembantu untuk membangun manajer inti kontainer.
     * Mencoba membuat instance manajer menggunakan refleksi untuk injeksi dependensi konstruktor.
     *
     * @param ContainerBuilder $builder Instance builder kontainer.
     * @param string $method Nama metode builder untuk menetapkan manajer (misalnya, 'withBindingRegistry').
     * @param array $config Konfigurasi untuk manajer tertentu.
     * @param string $defaultClass Nama kelas default untuk manajer jika tidak ditentukan atau gagal.
     * @param LoggerInterface $logger Logger untuk mencatat pesan.
     * @param array $knownDeps Dependensi yang diketahui yang dapat diinjeksikan ke konstruktor manajer.
     * @return void
     */
    private static function buildManager(ContainerBuilder $builder, string $method, array $config, string $defaultClass, LoggerInterface $logger, array $knownDeps): void
    {
        if (!($config['enabled'] ?? true)) {
            return; // Manajer dinonaktifkan
        }

        $class = $config['class'] ?? $defaultClass;

        if (class_exists($class)) {
            try {
                $reflector = new ReflectionClass($class);
                $constructor = $reflector->getConstructor();
                $params = [];

                if ($constructor) {
                    foreach ($constructor->getParameters() as $param) {
                        $type = $param->getType();
                        if ($type instanceof \ReflectionNamedType && isset($knownDeps[$type->getName()])) {
                            $params[] = $knownDeps[$type->getName()];
                        } elseif ($param->isDefaultValueAvailable()) {
                            $params[] = $param->getDefaultValue();
                        } else {
                            throw new ContainerException("Cannot auto-wire constructor for manager '{$class}'. Missing dependency for parameter '{$param->getName()}'.");
                        }
                    }
                }
                // Panggil metode builder dengan instance manajer yang dibuat
                $builder->$method($reflector->newInstanceArgs($params));
            } catch (Throwable $e) {
                $logger->error("Failed to build manager '{$class}': " . $e->getMessage());
                // Fallback ke implementasi default jika pembangunan gagal
                $builder->$method(new $defaultClass(...array_values($knownDeps)));
            }
        } else {
            $logger->warning("Manager class not found: {$class}. Using default implementation.");
            // Fallback ke implementasi default jika kelas tidak ditemukan
            $builder->$method(new $defaultClass(...array_values($knownDeps)));
        }
    }
}

