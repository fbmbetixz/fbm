<?php

namespace Core\Container\Exceptions;

/**
 * Pengecualian yang dilemparkan ketika pelanggaran keamanan terdeteksi dalam operasi kontainer.
 *
 * @package Core\Container\Exceptions
 */
class SecurityViolationException extends ContainerException {}

