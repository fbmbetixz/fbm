<?php

namespace Core\Container\Exceptions;

/**
 * Pengecualian yang dilemparkan ketika aturan arsitektur dilanggar.
 *
 * @package Core\Container\Exceptions
 */
class ArchitecturalViolationException extends ContainerException {}

