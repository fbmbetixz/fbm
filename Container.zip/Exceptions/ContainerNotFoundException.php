<?php

namespace Core\Container\Exceptions;

use Psr\Container\NotFoundExceptionInterface;

/**
 * Pengecualian yang dilemparkan ketika layanan atau binding tidak ditemukan di kontainer.
 *
 * @package Core\Container\Exceptions
 * @implements NotFoundExceptionInterface
 */
class ContainerNotFoundException extends \RuntimeException implements NotFoundExceptionInterface {}

