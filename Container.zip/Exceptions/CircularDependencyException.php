<?php

namespace Core\Container\Exceptions;

/**
 * Pengecualian yang dilemparkan ketika dependensi melingkar terdeteksi selama resolusi layanan.
 *
 * @package Core\Container\Exceptions
 */
class CircularDependencyException extends ContainerException {}

