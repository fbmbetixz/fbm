<?php

namespace Core\Container\Exceptions;

use Psr\Container\ContainerExceptionInterface;

/**
 * Pengecualian dasar untuk semua kesalahan yang terkait dengan kontainer.
 *
 * @package Core\Container\Exceptions
 * @implements ContainerExceptionInterface
 */
class ContainerException extends \RuntimeException implements ContainerExceptionInterface {}

