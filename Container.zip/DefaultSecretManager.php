<?php

namespace Core\Container;

use Core\Container\Interfaces\SecretManager;

/**
 * Implementasi default dari SecretManager.
 * Menyimpan provider untuk rahasia, bukan nilai rahasia itu sendiri.
 *
 * @package Core\Container
 * @implements SecretManager
 */
class DefaultSecretManager implements SecretManager
{
    /**
     * @var array<string, array{0: string, 1: callable}> Daftar rahasia yang terikat: ID => [key, provider].
     */
    private array $secrets = [];

    /**
     * @inheritDoc
     */
    public function bindSecret(string $id, string $key, callable $provider): void
    {
        $this->secrets[$id] = [$key, $provider];
    }

    /**
     * @inheritDoc
     */
    public function getSecret(string $id): mixed
    {
        try {
            return isset($this->secrets[$id]) ? call_user_func($this->secrets[$id][1], $this->secrets[$id][0]) : null;
        } catch (\Throwable $e) {
            // Log the error if a logger is available
            return null;
        }
    }

    /**
     * @inheritDoc
     */
    public function hasSecret(string $id): bool
    {
        return isset($this->secrets[$id]);
    }
}

