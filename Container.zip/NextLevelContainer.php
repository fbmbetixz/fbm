<?php

namespace Core\Container;

use Psr\Container\ContainerInterface;
use Psr\Log\LoggerInterface;
use Core\Container\Interfaces\BindingRegistry;
use Core\Container\Interfaces\Monitoring;
use Core\Container\Interfaces\EventDispatcher;
use Core\Container\Interfaces\SnapshotManager;
use Core\Container\Interfaces\SecretManager;
use Core\Container\Interfaces\ContextManager;
use Core\Container\Interfaces\DocGenerator;
use Core\Container\Interfaces\ContainerExtension;
use Core\Container\Interfaces\DelegationPolicy;
use Core\Container\Traits\BindingApiTrait;
use Core\Container\Traits\ExecutionApiTrait;
use Core\Container\Traits\LifecycleApiTrait;

/**
 * NextLevelContainer adalah implementasi Container Inversi Kontrol (IoC) yang canggih
 * dan berkinerja tinggi, menyediakan fitur-fitur seperti manajemen siklus hidup,
 * monitoring, snapshotting, manajemen rahasia, multi-tenancy, dan validasi arsitektur.
 *
 * Kontainer ini mendukung berbagai metode binding dan resolusi, termasuk autowiring,
 * injeksi berdasarkan atribut, dan injeksi berdasarkan tag.
 *
 * @package Core\Container
 * @implements ContainerInterface
 */
class NextLevelContainer implements ContainerInterface
{
    use BindingApiTrait, ExecutionApiTrait, LifecycleApiTrait;

    /**
     * @var BindingRegistry Registri untuk mengelola semua binding layanan dan alias.
     */
    protected BindingRegistry $registry;

    /**
     * @var Monitoring Sistem monitoring untuk melacak metrik resolusi dan kesehatan layanan.
     */
    protected Monitoring $monitor;

    /**
     * @var EventDispatcher Dispatcher peristiwa untuk menerbitkan dan mendengarkan peristiwa kontainer.
     */
    protected EventDispatcher $events;

    /**
     * @var SnapshotManager Manajer untuk mengelola snapshot status kontainer.
     */
    protected SnapshotManager $snapshot;

    /**
     * @var SecretManager Manajer untuk mengelola rahasia dan kredensial.
     */
    protected SecretManager $secrets;

    /**
     * @var ContextManager Manajer untuk mengelola konteks aplikasi dan binding dinamis.
     */
    protected ContextManager $context;

    /**
     * @var DocGenerator Generator dokumentasi untuk binding kontainer.
     */
    protected DocGenerator $doc;

    /**
     * @var LoggerInterface Logger untuk mencatat pesan dan kesalahan.
     */
    protected LoggerInterface $logger;

    /**
     * @var ContainerExtension[] Array ekstensi kontainer yang terdaftar.
     */
    protected array $extensions = [];

    /**
     * @var bool Menentukan apakah penulisan ulang binding diizinkan atau tidak.
     */
    private bool $strictOverwrite;

    /**
     * @var ContainerInterface|null Kontainer induk jika kontainer ini merupakan turunan.
     */
    private ?ContainerInterface $parentContainer = null;

    /**
     * @var DelegationPolicy|null Kebijakan yang menentukan apakah resolusi dapat didelegasikan ke kontainer induk.
     */
    private ?DelegationPolicy $delegationPolicy = null;

    /**
     * Membuat instance baru dari NextLevelContainer.
     *
     * @param BindingRegistry $registry Implementasi registri binding.
     * @param Monitoring $monitor Implementasi sistem monitoring.
     * @param EventDispatcher $events Implementasi dispatcher peristiwa.
     * @param SnapshotManager $snapshot Implementasi manajer snapshot.
     * @param SecretManager $secrets Implementasi manajer rahasia.
     * @param ContextManager $context Implementasi manajer konteks.
     * @param DocGenerator $doc Implementasi generator dokumentasi.
     * @param LoggerInterface $logger Implementasi logger.
     * @param ContainerExtension[] $extensions Array ekstensi kontainer.
     * @param bool $strictOverwrite Jika true, binding yang sudah ada tidak dapat ditimpa.
     * @param ContainerInterface|null $parentContainer Kontainer induk untuk delegasi.
     * @param DelegationPolicy|null $delegationPolicy Kebijakan delegasi ke kontainer induk.
     */
    public function __construct(
        BindingRegistry $registry,
        Monitoring $monitor,
        EventDispatcher $events,
        SnapshotManager $snapshot,
        SecretManager $secrets,
        ContextManager $context,
        DocGenerator $doc,
        LoggerInterface $logger,
        array $extensions = [],
        bool $strictOverwrite = false,
        ?ContainerInterface $parentContainer = null,
        ?DelegationPolicy $delegationPolicy = null
    ) {
        $this->registry = $registry;
        $this->monitor = $monitor;
        $this->events = $events;
        $this->snapshot = $snapshot;
        $this->secrets = $secrets;
        $this->context = $context;
        $this->doc = $doc;
        $this->logger = $logger;
        $this->extensions = $extensions;
        $this->strictOverwrite = $strictOverwrite;
        $this->parentContainer = $parentContainer;
        $this->delegationPolicy = $delegationPolicy ?? new AllowAllPolicy();
    }

    /**
     * Mengkloning instance kontainer.
     * Singletons dan instance scoped direset, dan manajer internal dikloning secara dangkal.
     */
    public function __clone()
    {
        $this->singletons = [];
        $this->disposableSingletons = [];
        $this->scopedInstances = [];
        $this->disposableScopedInstances = [];
        $this->registry = clone $this->registry;
        $this->context = clone $this->context;
        $this->secrets = clone $this->secrets;
    }

    /**
     * Menetapkan probe healthcheck untuk layanan tertentu.
     *
     * @param string $id ID layanan.
     * @param callable $probe Callable yang melakukan pemeriksaan kesehatan. Harus mengembalikan boolean.
     * @return void
     */
    public function setHealthcheck(string $id, callable $probe): void
    {
        $this->monitor->setHealthcheck($id, $probe);
    }

    /**
     * Menambahkan pusher metrik khusus yang akan dipanggil saat metrik resolusi diperbarui.
     *
     * @param callable $cb Callback yang akan menerima ID layanan dan statistik resolusi.
     * @return void
     */
    public function addMetricsPusher(callable $cb): void
    {
        $this->monitor->addMetricsPusher($cb);
    }

    /**
     * Mendaftarkan listener untuk event kontainer tertentu.
     *
     * @param string $event Nama event (misalnya, 'bind', 'resolve').
     * @param callable $cb Callback listener.
     * @return void
     */
    public function onEvent(string $event, callable $cb): void
    {
        $this->events->on($event, $cb);
    }

    /**
     * Mengambil statistik resolusi untuk layanan tertentu.
     *
     * @param string $id ID layanan.
     * @return array Statistik resolusi (count, total_time, avg_time, dll.).
     */
    public function getResolveStats(string $id): array
    {
        return $this->monitor->getResolveStats($id);
    }

    /**
     * Mendump semua statistik resolusi.
     *
     * @param string|null $sort Kunci untuk mengurutkan hasil (misalnya, 'total_time', 'count').
     * @return array Semua statistik resolusi, diurutkan jika ditentukan.
     */
    public function dumpResolveStats(string $sort = null): array
    {
        return $this->monitor->dumpResolveStats($sort);
    }

    /**
     * Mendump status kesehatan semua layanan yang terikat.
     *
     * @return array Array asosiatif dari ID layanan ke status kesehatannya.
     */
    public function dumpHealthStatus(): array
    {
        $allBoundIds = array_keys($this->registry->getAllBindings());
        $result = [];
        foreach ($allBoundIds as $id) {
            try {
                $instance = $this->get($id);
                $result[$id] = ['status' => $this->monitor->checkHealth($id, $instance)];
            } catch (\Throwable $e) {
                $result[$id] = ['status' => false, 'error' => $e->getMessage()];
            }
        }
        return $result;
    }

    /**
     * Mengambil log diagnostik resolusi layanan.
     *
     * @return array Log resolusi.
     */
    public function getDiagnostics(): array
    {
        return $this->monitor->getDiagnostics();
    }

    /**
     * Membersihkan log diagnostik resolusi layanan.
     *
     * @return void
     */
    public function clearDiagnostics(): void
    {
        $this->monitor->clearDiagnostics();
    }

    /**
     * Mendorong konteks baru ke dalam stack konteks.
     *
     * @param array $ctx Konteks yang akan didorong.
     * @return void
     */
    public function pushContext(array $ctx): void
    {
        $this->context->push($ctx);
    }

    /**
     * Mengeluarkan konteks dari stack konteks.
     *
     * @return void
     */
    public function popContext(): void
    {
        $this->context->pop();
    }

    /**
     * Mengambil instance kontainer yang dikloning untuk tenant tertentu.
     * Instance kontainer dikloning untuk setiap tenant untuk mengisolasi binding dan instance.
     *
     * @param string $tenantId ID tenant.
     * @return self Instance kontainer untuk tenant.
     */
    public function forTenant(string $tenantId): self
    {
        return $this->context->forTenant($tenantId, fn() => clone $this);
    }

    /**
     * Mengekspor status kontainer saat ini ke file JSON.
     *
     * @param string $file Path file untuk menyimpan snapshot.
     * @return void
     * @throws Exceptions\ContainerException Jika data snapshot tidak dapat diekspor.
     */
    public function exportSnapshot(string $file): void
    {
        $state = $this->exportSnapshotArray();
        $this->snapshot->export($state, $file);
    }

    /**
     * Mengimpor status kontainer dari file JSON.
     *
     * @param string $file Path file snapshot untuk diimpor.
     * @return void
     * @throws Exceptions\ContainerException Jika data snapshot tidak valid atau tidak dapat diimpor.
     */
    public function importSnapshot(string $file): void
    {
        $state = $this->snapshot->import($file);
        $this->importSnapshotArray($state);
    }

    /**
     * Mengekspor status kontainer saat ini sebagai array.
     *
     * @return array Array representasi status kontainer.
     */
    public function exportSnapshotArray(): array
    {
        return [
            'bindings' => $this->registry->getAllBindings(),
            'singletons' => $this->singletons,
            'aliases' => $this->registry->getAllAliases(),
            'tags' => $this->registry->getAllTags(),
            'strictTypes' => $this->registry->getAllStrictTypes(),
            'expiry' => $this->registry->getAllExpiry(),
            'tenants' => $this->snapshot->exportTenants($this->context->getTenants())
        ];
    }

    /**
     * Mengimpor status kontainer dari array.
     *
     * @param array $state Array yang berisi status kontainer.
     * @return void
     * @throws Exceptions\ContainerException Jika data snapshot tidak valid.
     */
    public function importSnapshotArray(array $state): void
    {
        if (!is_array($state)) {
            throw new Exceptions\ContainerException("Snapshot data must be an array.");
        }
        if (isset($state['bindings']) && is_array($state['bindings'])) {
            $this->registry->setAllBindings($state['bindings']);
        }
        if (isset($state['singletons']) && is_array($state['singletons'])) {
            $this->singletons = $state['singletons'];
        }
        if (isset($state['aliases']) && is_array($state['aliases'])) {
            $this->registry->setAllAliases($state['aliases']);
        }
        if (isset($state['tags']) && is_array($state['tags'])) {
            $this->registry->setAllTags($state['tags']);
        }
        if (isset($state['strictTypes']) && is_array($state['strictTypes'])) {
            $this->registry->setAllStrictTypes($state['strictTypes']);
        }
        if (isset($state['expiry']) && is_array($state['expiry'])) {
            $this->registry->setAllExpiry($state['expiry']);
        }
        if (isset($state['tenants']) && is_array($state['tenants'])) {
            $this->context->setTenants($this->snapshot->importTenants($state['tenants'], fn() => clone $this));
        }
    }

    /**
     * Membandingkan status kontainer ini dengan kontainer lain dan mengembalikan perbedaannya.
     *
     * @param NextLevelContainer $other Kontainer lain untuk dibandingkan.
     * @return array Array yang menunjukkan perbedaan (added, removed, changed).
     */
    public function diffWith(NextLevelContainer $other): array
    {
        return $this->snapshot->diff($this->exportSnapshotArray(), $other->exportSnapshotArray());
    }

    /**
     * Menghasilkan dokumentasi untuk binding kontainer.
     *
     * @param string $format Format output dokumentasi (misalnya, 'markdown', 'json').
     * @return string Dokumentasi yang dihasilkan.
     */
    public function generateDocs(string $format = 'markdown'): string
    {
        return $this->doc->generate($this->registry->getAllBindings(), $this->registry->getAllTags(), $format);
    }
}

