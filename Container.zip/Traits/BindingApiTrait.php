<?php

namespace Core\Container\Traits;

use Core\Container\Factory;
use Core\Container\Exceptions\ContainerException;
use Core\Container\Exceptions\ContainerNotFoundException;
use Core\Container\Interfaces\BindingRegistry;
use Core\Container\Interfaces\EventDispatcher;
use Core\Container\Interfaces\SecretManager;
use Core\Container\Interfaces\ContextManager;
use Psr\Log\LoggerInterface;

/**
 * Trait ini menyediakan metode untuk mengelola binding layanan dalam kontainer.
 * Ini bergantung pada properti yang diharapkan ada di kelas yang menggunakannya.
 *
 * @package Core\Container\Traits
 * @property BindingRegistry $registry
 * @property EventDispatcher $events
 * @property SecretManager $secrets
 * @property ContextManager $context
 * @property LoggerInterface $logger
 * @property bool $strictOverwrite
 * @property array $singletons
 * @property array $disposableSingletons
 * @property array $scopedInstances
 * @property array $disposableScopedInstances
 * @method assertNotSealed(string $action)
 * @method has(string $id)
 */
trait BindingApiTrait
{
    /**
     * Mengikat ID layanan ke pabrik (factory) atau kelas tertentu dengan opsi.
     * Jika binding sudah ada dan mode strictOverwrite aktif, akan melemparkan ContainerException.
     *
     * @param string $id ID unik untuk layanan.
     * @param callable|string|Factory $factory Sebuah callable, nama kelas, atau instance Factory yang menghasilkan layanan.
     * @param array $options Opsi tambahan untuk binding (misalnya, 'scope').
     * @return $this
     * @throws ContainerException Jika kontainer disegel atau factory tidak valid, atau jika binding ditimpa dalam mode strict.
     */
    public function bind(string $id, callable|string|Factory $factory, array $options = []): self
    {
        $this->assertNotSealed("register new bindings");

        if ($this->registry->hasBinding($id)) {
            if ($this->strictOverwrite) {
                throw new ContainerException("Binding ID '{$id}' cannot be overwritten in strict mode.");
            }
            $this->logger->warning("Binding ID '{$id}' is being overwritten.");
        }

        if (!is_callable($factory) && !(is_string($factory) && (class_exists($factory) || interface_exists($factory))) && !($factory instanceof Factory)) {
            throw new ContainerException("Invalid factory provided for binding '{$id}'.");
        }

        $this->registry->bind($id, ['factory' => $factory, 'options' => $options]);
        $this->events->fire('bind', $id, $factory, $options);
        return $this;
    }

    /**
     * Melepaskan binding layanan dari kontainer.
     * Ini juga menghapus instance singleton dan scoped yang terkait.
     *
     * @param string $id ID layanan yang akan dilepaskan.
     * @return bool True jika binding berhasil dilepaskan, false jika tidak ditemukan.
     * @throws ContainerException Jika kontainer disegel.
     */
    public function unbind(string $id): bool
    {
        $this->assertNotSealed("unbind a service");

        unset($this->singletons[$id]);
        unset($this->disposableSingletons[$id]);
        foreach ($this->scopedInstances as &$scope) {
            unset($scope[$id]);
        }
        foreach ($this->disposableScopedInstances as &$scope) {
            unset($scope[$id]);
        }

        $removed = $this->registry->unbind($id);
        $this->events->fire('unbind', $id);
        return $removed;
    }

    /**
     * Menambahkan dekorator ke layanan yang ada. Dekorator akan diterapkan
     * setiap kali layanan diselesaikan.
     *
     * @param string $id ID layanan yang akan didekorasi.
     * @param callable $decorator Callable yang menerima instance layanan dan kontainer, mengembalikan instance yang didekorasi.
     * @return $this
     * @throws ContainerException Jika kontainer disegel.
     * @throws ContainerNotFoundException Jika layanan yang akan didekorasi tidak ditemukan.
     */
    public function decorate(string $id, callable $decorator): self
    {
        $this->assertNotSealed("decorate a service");

        $resolvedId = $this->registry->resolveAlias($id);
        if (!$this->has($resolvedId)) {
            throw new ContainerNotFoundException("Cannot decorate '{$id}' because it has not been bound.");
        }

        $this->registry->addDecorator($resolvedId, $decorator);

        // Menghapus instance yang di-cache agar dekorator diterapkan pada resolusi berikutnya
        unset($this->singletons[$resolvedId]);
        foreach ($this->scopedInstances as &$scope) {
            unset($scope[$resolvedId]);
        }

        $this->events->fire('decorate', $id, $decorator);
        return $this;
    }

    /**
     * Mengikat layanan sebagai singleton, artinya hanya satu instance yang akan dibuat
     * dan digunakan kembali di seluruh siklus hidup kontainer.
     *
     * @param string $id ID unik untuk layanan singleton.
     * @param callable|string|Factory $factory Callable, nama kelas, atau instance Factory.
     * @param array $options Opsi tambahan untuk binding.
     * @return $this
     * @see bind()
     */
    public function singleton(string $id, callable|string|Factory $factory, array $options = []): self
    {
        return $this->bind($id, $factory, array_merge($options, ['scope' => 'singleton']));
    }

    /**
     * Mengikat layanan dengan cakupan kustom (misalnya, 'request').
     * Instance akan dibuat sekali per cakupan yang ditentukan.
     *
     * @param string $id ID unik untuk layanan.
     * @param callable|string|Factory $factory Callable, nama kelas, atau instance Factory.
     * @param string $scopeName Nama cakupan (misalnya, 'request', 'session').
     * @param array $options Opsi tambahan untuk binding.
     * @return $this
     * @see bind()
     */
    public function scope(string $id, callable|string|Factory $factory, string $scopeName = 'request', array $options = []): self
    {
        return $this->bind($id, $factory, array_merge($options, ['scope' => $scopeName]));
    }

    /**
     * Membuat alias untuk layanan yang ada. Mengakses alias akan menyelesaikan layanan target.
     *
     * @param string $id Alias yang akan dibuat.
     * @param string $target ID layanan target.
     * @return $this
     * @throws ContainerException Jika kontainer disegel.
     */
    public function alias(string $id, string $target): self
    {
        $this->assertNotSealed("create new aliases");
        $this->registry->alias($id, $target);
        $this->events->fire('alias', $id, $target);
        return $this;
    }

    /**
     * Menghapus alias yang ada dari kontainer.
     *
     * @param string $alias Alias yang akan dihapus.
     * @return bool True jika alias berhasil dihapus, false jika tidak ditemukan.
     * @throws ContainerException Jika kontainer disegel.
     */
    public function removeAlias(string $alias): bool
    {
        $this->assertNotSealed("remove an alias");
        $removed = $this->registry->removeAlias($alias);
        $this->events->fire('removeAlias', $alias);
        return $removed;
    }

    /**
     * Menandai satu atau beberapa layanan dengan tag tertentu.
     * Layanan yang ditandai dapat diselesaikan secara bersamaan berdasarkan tagnya.
     *
     * @param string|string[] $ids Satu atau array ID layanan yang akan ditandai.
     * @param string $tag Nama tag.
     * @return $this
     * @throws ContainerException Jika kontainer disegel.
     */
    public function tag(string|array $ids, string $tag): self
    {
        $this->assertNotSealed("tag a binding");
        foreach ((array)$ids as $id) {
            $this->registry->tag($id, $tag);
        }
        $this->events->fire('tag', $ids, $tag);
        return $this;
    }

    /**
     * Menghapus tag dari layanan.
     * Jika `$tag` adalah null, semua tag untuk layanan akan dihapus.
     *
     * @param string $id ID layanan.
     * @param string|null $tag Nama tag yang akan dihapus.
     * @return void
     * @throws ContainerException Jika kontainer disegel.
     */
    public function untag(string $id, ?string $tag = null): void
    {
        $this->assertNotSealed("untag a binding");
        $this->registry->untag($id, $tag);
        $this->events->fire('untag', $id, $tag);
    }

    /**
     * Mengikat rahasia (secret) ke ID tertentu.
     * Rahasia tidak disimpan di kontainer, tetapi diperoleh melalui provider.
     *
     * @param string $id ID unik untuk rahasia.
     * @param string $key Kunci rahasia (misalnya, nama variabel lingkungan atau kunci vault).
     * @param callable $provider Callable yang mengambil kunci rahasia dan mengembalikan nilainya.
     * @return $this
     */
    public function bindSecret(string $id, string $key, callable $provider): self
    {
        $this->secrets->bindSecret($id, $key, $provider);
        $this->events->fire('bindSecret', $id);
        return $this;
    }

    /**
     * Mengikat binding dinamis yang resolusinya bergantung pada konteks saat ini.
     *
     * @param string $id ID unik untuk binding dinamis.
     * @param callable $resolver Callable yang menerima array konteks dan kontainer, mengembalikan layanan.
     * @return $this
     */
    public function bindDynamic(string $id, callable $resolver): self
    {
        $this->context->bindDynamic($id, $resolver);
        $this->events->fire('bindDynamic', $id);
        return $this;
    }

    /**
     * Menetapkan tipe ketat yang harus diimplementasikan atau diwarisi oleh instance layanan
     * yang diselesaikan untuk ID tertentu.
     *
     * @param string $id ID layanan.
     * @param string $type Nama kelas atau antarmuka yang diharapkan.
     * @return $this
     */
    public function setStrictType(string $id, string $type): self
    {
        $this->registry->setStrictType($id, $type);
        return $this;
    }

    /**
     * Mengatur konfigurasi kedaluwarsa untuk layanan yang terikat.
     *
     * @param string $id ID layanan.
     * @param int $ttl Waktu hidup (Time To Live) dalam detik.
     * @param bool $sliding Jika true, waktu kedaluarsa diperpanjang setiap kali layanan diakses.
     * @return $this
     */
    public function setExpiry(string $id, int $ttl, bool $sliding = false): self
    {
        $this->registry->setExpiry($id, $ttl, $sliding);
        return $this;
    }
}

