<?php

namespace Core\Container\Traits;

use Core\Container\Exceptions\ContainerException;
use Core\Container\Interfaces\Disposable;
use Core\Container\Interfaces\EventDispatcher;
use Psr\Container\ContainerInterface;

/**
 * Trait ini menyediakan metode untuk mengelola siklus hidup kontainer,
 * seperti penyegelan, pengaturan ulang cakupan, dan pematian.
 * Ini bergantung pada properti yang diharapkan ada di kelas yang menggunakannya.
 *
 * @package Core\Container\Traits
 * @property EventDispatcher $events
 * @property array $scopedInstances
 * @property array $disposableScopedInstances
 * @property array $singletons
 * @property array $disposableSingletons
 * @property ContainerInterface|null $parentContainer
 */
trait LifecycleApiTrait
{
    /**
     * @var bool Menunjukkan apakah kontainer telah disegel.
     */
    private bool $isSealed = false;

    /**
     * @var bool Menunjukkan apakah profiling diaktifkan.
     */
    private bool $profilingEnabled = false;

    /**
     * Menyegel kontainer, mencegah perubahan lebih lanjut pada binding dan alias.
     *
     * @return void
     * @throws ContainerException Jika kontainer sudah disegel.
     */
    public function seal(): void
    {
        if ($this->isSealed) {
            throw new ContainerException("Cannot seal the container. It is already sealed.");
        }
        $this->isSealed = true;
        $this->events->fire('seal', $this);
    }

    /**
     * Memeriksa apakah kontainer telah disegel.
     *
     * @return bool True jika disegel, false jika tidak.
     */
    public function isSealed(): bool
    {
        return $this->isSealed;
    }

    /**
     * Mengaktifkan atau menonaktifkan profiling untuk kontainer.
     *
     * @param bool $enable True untuk mengaktifkan, false untuk menonaktifkan.
     * @return void
     */
    public function enableProfiling(bool $enable = true): void
    {
        $this->profilingEnabled = $enable;
        // Implementasi lebih lanjut untuk mengaktifkan/menonaktifkan pengumpulan data profiling
        // mungkin diperlukan di DefaultMonitoring atau komponen lain.
    }

    /**
     * Mereset semua instance yang di-cache untuk cakupan tertentu.
     * Jika instance mengimplementasikan Disposable, metode dispose() akan dipanggil.
     *
     * @param string $scope Nama cakupan yang akan direset.
     * @return void
     */
    public function resetScope(string $scope): void
    {
        if (isset($this->disposableScopedInstances[$scope])) {
            foreach ($this->disposableScopedInstances[$scope] as $instance) {
                if ($instance instanceof Disposable) {
                    $instance->dispose();
                }
            }
        }
        unset($this->scopedInstances[$scope]);
        unset($this->disposableScopedInstances[$scope]);
        $this->events->fire('resetScope', $scope, $this);
    }

    /**
     * Mematikan kontainer, mereset semua cakupan dan membuang semua singleton yang dapat dibuang.
     *
     * @return void
     */
    public function shutdown(): void
    {
        // Reset semua cakupan yang ada
        $allScopeNames = array_keys($this->scopedInstances);
        foreach ($allScopeNames as $scopeName) {
            $this->resetScope($scopeName);
        }

        // Buang semua singleton yang dapat dibuang
        foreach ($this->disposableSingletons as $instance) {
            if ($instance instanceof Disposable) {
                $instance->dispose();
            }
        }
        $this->singletons = [];
        $this->disposableSingletons = [];

        $this->events->fire('shutdown', $this);
    }

    /**
     * Mengambil kontainer induk jika ada.
     *
     * @return ContainerInterface|null Kontainer induk atau null jika tidak ada.
     */
    public function getParent(): ?ContainerInterface
    {
        return $this->parentContainer;
    }

    /**
     * Memastikan kontainer tidak disegel sebelum melakukan tindakan tertentu.
     *
     * @param string $action Deskripsi tindakan yang dicoba.
     * @return void
     * @throws ContainerException Jika kontainer disegel.
     */
    private function assertNotSealed(string $action): void
    {
        if ($this->isSealed) {
            throw new ContainerException("Cannot {$action}. The container is sealed.");
        }
    }
}

