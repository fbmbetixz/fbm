<?php

namespace Core\Container\Traits;

use Core\Container\Exceptions\CircularDependencyException;
use Core\Container\Exceptions\ContainerException;
use Core\Container\Exceptions\ContainerNotFoundException;
use Core\Container\Interfaces\BindingRegistry;
use Core\Container\Interfaces\ContextManager;
use Core\Container\Interfaces\DelegationPolicy;
use Core\Container\Interfaces\Disposable;
use Core\Container\Interfaces\EventDispatcher;
use Core\Container\Interfaces\Monitoring;
use Core\Container\Interfaces\SecretManager;
use Core\Container\Interfaces\ContainerExtension;
use Core\Container\Interfaces\Factory;
use Core\Container\Attributes\Inject;
use Core\Container\Attributes\InjectTag;
use Core\Container\Attributes\PropertyInject;
use Core\Container\Attributes\SetterInject;
use Psr\Container\ContainerInterface;
use Psr\Log\LoggerInterface;
use ReflectionClass;
use ReflectionMethod;
use ReflectionNamedType;
use ReflectionProperty;
use Throwable;

/**
 * Trait ini menyediakan metode untuk resolusi layanan dan injeksi dependensi.
 * Ini bergantung pada properti yang diharapkan ada di kelas yang menggunakannya.
 *
 * @package Core\Container\Traits
 * @property BindingRegistry $registry
 * @property Monitoring $monitor
 * @property EventDispatcher $events
 * @property SecretManager $secrets
 * @property ContextManager $context
 * @property LoggerInterface $logger
 * @property ContainerExtension[] $extensions
 * @property ContainerInterface|null $parentContainer
 * @property DelegationPolicy $delegationPolicy
 * @property array $singletons
 * @property array $disposableSingletons
 * @property array $scopedInstances
 * @property array $disposableScopedInstances
 */
trait ExecutionApiTrait
{
    /**
     * @var array<string, ReflectionClass|ReflectionMethod|ReflectionProperty[]> Cache untuk objek refleksi.
     */
    private static array $reflectionCache = [];

    /**
     * @var array<string, int> Stack resolusi saat ini untuk mendeteksi dependensi melingkar.
     */
    private array $resolutionStack = [];

    /**
     * @var array<string, mixed> Cache untuk instance singleton.
     */
    protected array $singletons = [];

    /**
     * @var array<string, Disposable> Cache untuk instance singleton yang dapat dibuang.
     */
    protected array $disposableSingletons = [];

    /**
     * @var array<string, array<string, mixed>> Cache untuk instance scoped per nama cakupan.
     */
    protected array $scopedInstances = [];

    /**
     * @var array<string, array<string, Disposable>> Cache untuk instance scoped yang dapat dibuang per nama cakupan.
     */
    protected array $disposableScopedInstances = [];

    /**
     * Membersihkan instance yang kedaluwarsa atau yang tidak lagi diperlukan dari cache.
     * Jika instance adalah Disposable, metode dispose() akan dipanggil.
     *
     * @param string $resolvedId ID layanan yang diselesaikan.
     * @param string|null $scope Nama cakupan (jika spesifik, null untuk semua cakupan).
     * @return void
     */
    private function clearExpiredInstance(string $resolvedId, ?string $scope = null): void
    {
        if (isset($this->singletons[$resolvedId])) {
            if (isset($this->disposableSingletons[$resolvedId]) && $this->disposableSingletons[$resolvedId] instanceof Disposable) {
                $this->disposableSingletons[$resolvedId]->dispose();
            }
            unset($this->singletons[$resolvedId]);
            unset($this->disposableSingletons[$resolvedId]);
        }

        if ($scope !== null && isset($this->scopedInstances[$scope][$resolvedId])) {
            if (isset($this->disposableScopedInstances[$scope][$resolvedId]) && $this->disposableScopedInstances[$scope][$resolvedId] instanceof Disposable) {
                $this->disposableScopedInstances[$scope][$resolvedId]->dispose();
            }
            unset($this->scopedInstances[$scope][$resolvedId]);
            unset($this->disposableScopedInstances[$scope][$resolvedId]);
        }

        // Jika scope adalah null, bersihkan dari semua scoped instances
        if ($scope === null) {
            foreach ($this->scopedInstances as $scopeName => $instances) {
                if (isset($instances[$resolvedId])) {
                    if (isset($this->disposableScopedInstances[$scopeName][$resolvedId]) && $this->disposableScopedInstances[$scopeName][$resolvedId] instanceof Disposable) {
                        $this->disposableScopedInstances[$scopeName][$resolvedId]->dispose();
                    }
                    unset($this->scopedInstances[$scopeName][$resolvedId]);
                    unset($this->disposableScopedInstances[$scopeName][$resolvedId]);
                }
            }
        }
    }

    /**
     * Memeriksa apakah kontainer memiliki binding untuk ID layanan tertentu.
     * Ini juga memeriksa rahasia, binding dinamis, tenant, dan kontainer induk.
     *
     * @param string $id ID layanan.
     * @return bool True jika layanan dapat diselesaikan, false jika tidak.
     */
    public function has(string $id): bool
    {
        $resolvedId = $this->registry->resolveAlias($id);

        // Periksa dan hapus jika kedaluarsa
        if ($this->registry->checkExpiry($resolvedId)) {
            $this->clearExpiredInstance($resolvedId);
        }

        if ($this->registry->hasBinding($resolvedId) || class_exists($resolvedId) || $this->secrets->hasSecret($resolvedId) || $this->context->resolveDynamic($resolvedId, $this) !== null || str_starts_with($resolvedId, '__tenant__')) {
            return true;
        }

        // Delegasikan ke kontainer induk jika diizinkan
        if ($this->parentContainer && $this->delegationPolicy->canDelegate($id, $this, $this->parentContainer)) {
            return $this->parentContainer->has($id);
        }

        return false;
    }

    /**
     * Mengambil instance layanan dari kontainer. Ini akan selalu mencoba
     * menyelesaikan layanan sebagai singleton jika belum ada.
     *
     * @param string $id ID layanan yang akan diambil.
     * @return mixed Instance layanan.
     * @throws ContainerNotFoundException Jika layanan tidak dapat ditemukan.
     * @throws ContainerException Jika terjadi kesalahan selama resolusi.
     */
    public function get(string $id): mixed
    {
        return $this->resolve($id, [], 'singleton');
    }

    /**
     * Membuat instance baru dari layanan, mengabaikan cakupan singleton/scoped
     * dan memungkinkan argumen konstruktor/factory kustom.
     *
     * @param string $id ID layanan yang akan dibuat.
     * @param array $args Argumen yang akan diteruskan ke konstruktor atau factory, diindeks berdasarkan nama parameter.
     * @return mixed Instance layanan yang baru dibuat.
     * @throws \InvalidArgumentException Jika argumen posisi diberikan.
     * @throws ContainerNotFoundException Jika layanan tidak dapat ditemukan.
     * @throws ContainerException Jika terjadi kesalahan selama resolusi.
     */
    public function make(string $id, array $args = []): mixed
    {
        if (!empty($args) && array_keys($args) === range(0, count($args) - 1)) {
            throw new \InvalidArgumentException("Positional arguments are not supported in make(). Arguments must be associative (key-value pairs).");
        }
        return $this->resolve($id, $args, null); // null scope berarti selalu buat instance baru
    }

    /**
     * Menyelesaikan semua layanan yang terkait dengan tag tertentu.
     * Mengembalikan generator untuk efisiensi memori.
     *
     * @param string $tag Tag yang akan diselesaikan.
     * @return \Generator Iterator yang menghasilkan instance layanan.
     */
    public function resolveByTag(string $tag): \Generator
    {
        foreach ($this->registry->getByTag($tag) as $id) {
            yield $this->get($id);
        }
    }

    /**
     * Metode inti untuk menyelesaikan layanan dari kontainer.
     * Menangani dependensi melingkar, cakupan, injeksi, dan hook ekstensi.
     *
     * @param string $id ID layanan yang akan diselesaikan.
     * @param array $args Argumen kustom untuk konstruktor/factory.
     * @param string|null $scope Cakupan yang diminta ('singleton', nama cakupan kustom, atau null untuk transient).
     * @return mixed Instance layanan yang diselesaikan.
     * @throws CircularDependencyException Jika dependensi melingkar terdeteksi.
     * @throws ContainerNotFoundException Jika layanan tidak dapat ditemukan.
     * @throws ContainerException Jika terjadi kesalahan selama resolusi atau injeksi.
     * @throws \TypeError Jika tipe ketat dilanggar.
     */
    protected function resolve(string $id, array $args, ?string $scope): mixed
    {
        $originalId = $id;
        $resolvedId = $this->registry->resolveAlias($id);

        // Deteksi dependensi melingkar
        if (isset($this->resolutionStack[$resolvedId])) {
            throw new CircularDependencyException('Circular dependency detected for: ' . $resolvedId . ' | Stack: ' . implode(' -> ', array_keys($this->resolutionStack)));
        }
        $this->resolutionStack[$resolvedId] = 1; // Tandai sebagai sedang diselesaikan

        $startTime = microtime(true);
        $startMemory = memory_get_usage();
        $instance = null;
        $success = false;

        try {
            // Hook beforeResolve untuk ekstensi
            foreach ($this->extensions as $ext) {
                try {
                    $ext->beforeResolve($originalId, $this);
                } catch (Throwable $e) {
                    $this->logger->error("Extension '{$ext::class}' beforeResolve hook failed for ID '{$originalId}': " . $e->getMessage(), ['exception' => $e]);
                    throw new ContainerException("Extension beforeResolve failed for '{$originalId}'.", 0, $e);
                }
            }

            // Periksa kedaluwarsa dan hapus jika perlu
            if ($this->registry->checkExpiry($resolvedId)) {
                $this->clearExpiredInstance($resolvedId, $scope);
            }

            // Periksa cache singleton atau scoped
            if ($scope === 'singleton' && isset($this->singletons[$resolvedId])) {
                $this->registry->extendExpiryIfSliding($resolvedId);
                $success = true; // Dianggap berhasil karena diambil dari cache
                return $this->singletons[$resolvedId];
            } elseif ($scope && isset($this->scopedInstances[$scope][$resolvedId])) {
                $this->registry->extendExpiryIfSliding($resolvedId);
                $success = true; // Dianggap berhasil karena diambil dari cache
                return $this->scopedInstances[$scope][$resolvedId];
            }

            // Coba rahasia
            $secret = $this->secrets->getSecret($resolvedId);
            if ($secret !== null) {
                $success = true;
                return $secret;
            }

            // Coba binding dinamis
            $dyn = $this->context->resolveDynamic($resolvedId, $this);
            if ($dyn !== null) {
                $success = true;
                return $dyn;
            }

            // Coba instance tenant
            if (str_starts_with($resolvedId, '__tenant__')) {
                $tenantContainer = $this->context->getTenants()[$resolvedId] ?? null;
                if ($tenantContainer !== null) {
                    $success = true;
                    return $tenantContainer;
                }
            }

            // Coba binding yang terdaftar atau kelas yang ada
            $binding = $this->registry->getBinding($resolvedId);
            if ($binding) {
                $instance = $this->createInstance($binding, $args);
            } elseif (class_exists($resolvedId)) {
                // Autowire kelas jika tidak ada binding eksplisit
                $instance = $this->createInstance(['factory' => $resolvedId, 'options' => []], $args);
            } else {
                // Coba delegasikan ke kontainer induk
                if ($this->parentContainer && $this->delegationPolicy->canDelegate($resolvedId, $this, $this->parentContainer)) {
                    $success = true; // Asumsi parent akan berhasil atau melemparkan pengecualiannya sendiri
                    return $this->parentContainer->get($resolvedId);
                }
                throw new ContainerNotFoundException("No binding, class, secret, dynamic binding, or tenant found for [{$resolvedId}] in container or its parents.");
            }

            // Terapkan dekorator
            $decorators = $this->registry->getDecorators($resolvedId);
            foreach (array_reverse($decorators) as $decorator) {
                $instance = $decorator($instance, $this);
            }

            // Lakukan injeksi properti dan setter
            if (($binding['options']['property_injection'] ?? false) || ($binding['options']['setter_injection'] ?? false)) {
                $this->performInjection($instance);
            }

            // Validasi nullability
            $allowNull = $binding['options']['nullable'] ?? false;
            if ($instance === null && !$allowNull) {
                throw new ContainerException("Factory for '{$resolvedId}' returned null but was not marked as nullable.");
            }

            // Validasi tipe ketat
            $strictType = $this->registry->getStrictType($resolvedId);
            if ($strictType && !($instance instanceof $strictType)) {
                throw new \TypeError("Instance for '{$resolvedId}' must be of type '{$strictType}', but is " . get_debug_type($instance));
            }

            // Simpan instance ke cache jika memiliki cakupan
            $bindingScope = $scope ?? ($binding['options']['scope'] ?? null);
            if ($instance instanceof Disposable) {
                if ($bindingScope === 'singleton') {
                    $this->disposableSingletons[$resolvedId] = $instance;
                } elseif ($bindingScope) {
                    if (!isset($this->disposableScopedInstances[$bindingScope])) {
                        $this->disposableScopedInstances[$bindingScope] = [];
                    }
                    $this->disposableScopedInstances[$bindingScope][$resolvedId] = $instance;
                }
            }

            if ($bindingScope === 'singleton') {
                $this->singletons[$resolvedId] = $instance;
            } elseif ($bindingScope) {
                if (!isset($this->scopedInstances[$bindingScope])) {
                    $this->scopedInstances[$bindingScope] = [];
                }
                $this->scopedInstances[$bindingScope][$resolvedId] = $instance;
            }

            $this->registry->extendExpiryIfSliding($resolvedId);
            $success = true;
            return $instance;

        } catch (Throwable $e) {
            $success = false;
            $this->logger->error("Failed to resolve '{$originalId}': " . $e->getMessage(), ['exception' => $e]);
            $this->events->fire('resolve:failed', $originalId, $e, $this);
            throw $e;
        } finally {
            unset($this->resolutionStack[$resolvedId]); // Hapus dari stack resolusi
            $this->afterResolveHook($resolvedId, $instance, $startTime, $success, $startMemory);
        }
    }

    /**
     * Membuat instance layanan dari definisi binding.
     * Mendukung factory callable, nama kelas, dan instance Factory.
     *
     * @param array $binding Definisi binding layanan.
     * @param array $userArgs Argumen kustom yang diberikan oleh pengguna.
     * @return mixed Instance layanan yang dibuat.
     * @throws ContainerException Jika factory tidak valid atau kelas tidak dapat diinstansiasi.
     */
    private function createInstance(array $binding, array $userArgs): mixed
    {
        $factory = $binding['factory'];

        if (is_string($factory) && class_exists($factory)) {
            // Autowiring untuk kelas
            if (!isset(self::$reflectionCache[$factory])) {
                self::$reflectionCache[$factory] = new ReflectionClass($factory);
            }
            /** @var ReflectionClass $reflector */
            $reflector = self::$reflectionCache[$factory];

            if (!$reflector->isInstantiable()) {
                throw new ContainerException("Cannot create instance of '{$factory}' because it is not instantiable (e.g., abstract or interface).");
            }

            if (!$constructor = $reflector->getConstructor()) {
                return $reflector->newInstance(); // Tidak ada konstruktor, buat instance tanpa argumen
            }

            $params = $this->resolveParameters($constructor, $userArgs);
            return $reflector->newInstanceArgs($params);

        } elseif ($factory instanceof Factory || is_callable($factory)) {
            // Panggil factory callable
            return $factory($this, ...$userArgs);
        }

        throw new ContainerException("Invalid factory type for binding '{$factory}'.");
    }

    /**
     * Menyelesaikan parameter untuk metode (konstruktor atau setter) menggunakan autowiring
     * atau atribut injeksi.
     *
     * @param ReflectionMethod $method Metode yang parameternya akan diselesaikan.
     * @param array $userArgs Argumen yang diberikan oleh pengguna untuk parameter tertentu.
     * @return array Array argumen yang diselesaikan.
     * @throws ContainerException Jika parameter tidak dapat diselesaikan atau variadic.
     * @throws ContainerNotFoundException Jika dependensi yang diinjeksi tidak ditemukan.
     */
    private function resolveParameters(ReflectionMethod $method, array $userArgs): array
    {
        $params = [];
        $className = $method->getDeclaringClass()->getName();

        foreach ($method->getParameters() as $param) {
            $paramName = $param->getName();

            if ($param->isVariadic()) {
                throw new ContainerException("Autowiring variadic parameters is not supported for {$className}::{$method->getName()}().");
            }

            // 1. Argumen yang diberikan pengguna memiliki prioritas tertinggi
            if (array_key_exists($paramName, $userArgs)) {
                $params[] = $userArgs[$paramName];
                continue;
            }

            // 2. Injeksi berdasarkan atribut #[Inject]
            $attributes = $param->getAttributes(Inject::class, \ReflectionAttribute::IS_INSTANCEOF);
            if (!empty($attributes)) {
                /** @var Inject $injectAttr */
                $injectAttr = $attributes[0]->newInstance();
                $params[] = $this->get($injectAttr->id);
                continue;
            }

            // 3. Injeksi berdasarkan atribut #[InjectTag]
            $attributes = $param->getAttributes(InjectTag::class, \ReflectionAttribute::IS_INSTANCEOF);
            if (!empty($attributes)) {
                /** @var InjectTag $injectTagAttr */
                $injectTagAttr = $attributes[0]->newInstance();
                $params[] = iterator_to_array($this->resolveByTag($injectTagAttr->tag));
                continue;
            }

            // 4. Autowiring berdasarkan tipe (kelas/antarmuka)
            $type = $param->getType();
            if ($type instanceof ReflectionNamedType && !$type->isBuiltin()) {
                try {
                    $params[] = $this->get($type->getName());
                    continue;
                } catch (ContainerNotFoundException $e) {
                    // Jika tidak ditemukan, periksa apakah opsional
                    if ($param->isOptional()) {
                        $params[] = $param->getDefaultValue();
                        continue;
                    }
                    throw $e; // Re-throw jika wajib
                }
            }

            // 5. Gunakan nilai default jika tersedia
            if ($param->isDefaultValueAvailable()) {
                $params[] = $param->getDefaultValue();
                continue;
            }

            // 6. Izinkan null jika parameter memungkinkan null
            if ($param->allowsNull()) {
                $params[] = null;
                continue;
            }

            // Jika tidak ada metode resolusi yang berhasil
            throw new ContainerException("Cannot resolve parameter '{$paramName}' for {$className}::{$method->getName()}(). No binding, default value, or nullable type found.");
        }

        return $params;
    }

    /**
     * Melakukan injeksi properti dan setter pada instance yang diberikan,
     * berdasarkan atribut #[PropertyInject] dan #[SetterInject].
     *
     * @param object $instance Instance objek yang akan diinjeksi.
     * @return void
     * @throws ContainerException Jika terjadi kesalahan selama injeksi.
     * @throws ContainerNotFoundException Jika dependensi yang akan diinjeksi tidak ditemukan.
     */
    private function performInjection(object $instance): void
    {
        $reflector = new ReflectionClass($instance);
        $className = $reflector->getName();

        // Cache properti publik
        if (!isset(self::$reflectionCache[$className . '::properties'])) {
            self::$reflectionCache[$className . '::properties'] = $reflector->getProperties(ReflectionProperty::IS_PUBLIC);
        }
        // Cache metode publik
        if (!isset(self::$reflectionCache[$className . '::methods'])) {
            self::$reflectionCache[$className . '::methods'] = $reflector->getMethods(ReflectionMethod::IS_PUBLIC);
        }

        /** @var ReflectionProperty $property */
        foreach (self::$reflectionCache[$className . '::properties'] as $property) {
            if ($property->isStatic()) {
                continue;
            }
            $attributes = $property->getAttributes(PropertyInject::class, \ReflectionAttribute::IS_INSTANCEOF);
            if (!empty($attributes)) {
                /** @var PropertyInject $injectAttr */
                $injectAttr = $attributes[0]->newInstance();
                $id = $injectAttr->id;
                try {
                    $property->setValue($instance, $this->get($id));
                } catch (Throwable $e) {
                    throw new ContainerException("Failed to inject property '{$property->getName()}' for '{$className}': " . $e->getMessage(), 0, $e);
                }
            }
        }

        /** @var ReflectionMethod $method */
        foreach (self::$reflectionCache[$className . '::methods'] as $method) {
            if ($method->isStatic() || $method->isConstructor() || $method->isDestructor()) {
                continue;
            }
            $attributes = $method->getAttributes(SetterInject::class, \ReflectionAttribute::IS_INSTANCEOF);
            if (!empty($attributes)) {
                try {
                    $params = $this->resolveParameters($method, []);
                    $method->invokeArgs($instance, $params);
                } catch (Throwable $e) {
                    throw new ContainerException("Failed to inject setter method '{$method->getName()}' for '{$className}': " . $e->getMessage(), 0, $e);
                }
            }
        }
    }

    /**
     * Hook yang dipanggil setelah layanan diselesaikan (berhasil atau gagal).
     * Mencatat metrik resolusi dan memicu hook afterResolve ekstensi.
     *
     * @param string $id ID layanan yang diselesaikan.
     * @param mixed $result Instance layanan yang diselesaikan (atau null jika gagal).
     * @param float $start Waktu mulai resolusi.
     * @param bool $success Status keberhasilan resolusi.
     * @param float $startMemory Penggunaan memori pada awal resolusi.
     * @return void
     * @throws ContainerException Jika hook afterResolve ekstensi gagal.
     */
    protected function afterResolveHook(string $id, mixed $result, float $start, bool $success, float $startMemory): void
    {
        $this->monitor->recordResolve($id, $start, $success, $startMemory);

        foreach ($this->extensions as $ext) {
            try {
                $ext->afterResolve($id, $result, $this);
            } catch (Throwable $e) {
                $this->logger->error("Extension '{$ext::class}' afterResolve hook failed for ID '{$id}': " . $e->getMessage(), ['exception' => $e]);
                throw new ContainerException("Extension afterResolve failed for '{$id}'.", 0, $e);
            }
        }

        $this->events->fire('resolve', $id, $result, $this);
    }
}

