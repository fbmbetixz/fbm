<?php

namespace Core\Container;

use Core\Container\Interfaces\EventDispatcher;

/**
 * Implementasi default dari EventDispatcher.
 * Menyediakan fungsionalitas dasar untuk mendaftarkan dan memicu event.
 *
 * @package Core\Container
 * @implements EventDispatcher
 */
class DefaultEventDispatcher implements EventDispatcher
{
    /**
     * @var array<string, callable[]> Daftar listener event, diindeks berdasarkan nama event.
     */
    private array $listeners = [];

    /**
     * @inheritDoc
     */
    public function on(string $event, callable $cb): void
    {
        if (!is_callable($cb)) {
            throw new \InvalidArgumentException("Listener for event '{$event}' must be callable.");
        }
        $this->listeners[$event][] = $cb;
    }

    /**
     * @inheritDoc
     */
    public function fire(string $event, ...$args): array
    {
        $results = [];
        foreach ($this->listeners[$event] ?? [] as $cb) {
            try {
                $results[] = $cb(...$args);
            } catch (\Throwable $e) {
                // Logging error di sini bisa dilakukan jika ada logger yang diinjeksikan
                // Untuk kesederhanaan, kita hanya mencatat kegagalan.
                $results[] = false;
            }
        }
        return $results;
    }
}

