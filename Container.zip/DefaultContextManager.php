<?php

namespace Core\Container;

use Core\Container\Interfaces\ContextManager;
use Psr\Container\ContainerInterface;

/**
 * Implementasi default dari ContextManager.
 * Mengelola stack konteks, binding dinamis, dan instance tenant.
 *
 * @package Core\Container
 * @implements ContextManager
 */
class DefaultContextManager implements ContextManager
{
    /**
     * @var array<array<string, mixed>> Stack konteks.
     */
    private array $contextStack = [];

    /**
     * @var array<string, callable> Binding dinamis (ID => resolver callable).
     */
    private array $dynamicBindings = [];

    /**
     * @var array<string, mixed> Instance tenant yang di-cache.
     */
    private array $tenants = [];

    /**
     * Mengkloning instance manajer konteks.
     * Memastikan array internal di-copy by value.
     */
    public function __clone()
    {
        $this->contextStack = $this->contextStack;
        $this->dynamicBindings = $this->dynamicBindings;
        $this->tenants = $this->tenants;
    }

    /**
     * @inheritDoc
     */
    public function push(array $ctx): void
    {
        $this->contextStack[] = $ctx;
    }

    /**
     * @inheritDoc
     */
    public function pop(): void
    {
        array_pop($this->contextStack);
    }

    /**
     * @inheritDoc
     */
    public function current(): array
    {
        return end($this->contextStack) ?: [];
    }

    /**
     * @inheritDoc
     */
    public function bindDynamic(string $id, callable $resolver): void
    {
        $this->dynamicBindings[$id] = $resolver;
    }

    /**
     * @inheritDoc
     */
    public function resolveDynamic(string $id, ContainerInterface $container): mixed
    {
        if (!isset($this->dynamicBindings[$id])) {
            return null;
        }
        $ctx = $this->current();
        if (!$ctx) {
            return null;
        }
        try {
            return $this->dynamicBindings[$id]($ctx, $container);
        } catch (\Throwable $e) {
            // Log the error if a logger is available
            return null;
        }
    }

    /**
     * @inheritDoc
     */
    public function forTenant(string $tenantId, callable $factory): mixed
    {
        $key = '__tenant__' . $tenantId;
        if (!isset($this->tenants[$key])) {
            $this->tenants[$key] = $factory();
        }
        return $this->tenants[$key];
    }

    /**
     * @inheritDoc
     */
    public function getTenants(): array
    {
        return $this->tenants;
    }

    /**
     * @inheritDoc
     */
    public function setTenants(array $tenants): void
    {
        $this->tenants = $tenants;
    }
}

