<?php

namespace Core\Container;

use Psr\Log\LoggerInterface;

/**
 * Validator konfigurasi untuk memeriksa struktur dan integritas
 * definisi binding kontainer.
 *
 * @package Core\Container
 */
class ConfigValidator
{
    /**
     * @var array Daftar kesalahan validasi yang ditemukan.
     */
    private array $errors = [];

    /**
     * @var LoggerInterface Logger untuk mencatat pesan validasi.
     */
    public function __construct(private LoggerInterface $logger) {}

    /**
     * Memvalidasi array konfigurasi kontainer.
     *
     * @param array $config Array konfigurasi kontainer.
     * @return bool True jika konfigurasi valid, false jika tidak.
     */
    public function validate(array $config): bool
    {
        $this->errors = [];
        $this->validateBindings($config['service_definitions']['bindings'] ?? []);

        foreach ($this->errors as $error) {
            $this->logger->error("Configuration validation failed: " . $error);
        }

        return empty($this->errors);
    }

    /**
     * Memvalidasi definisi binding individu.
     *
     * @param array $bindings Array definisi binding.
     * @return void
     */
    private function validateBindings(array $bindings): void
    {
        $validKeys = ['factory', 'options', 'strict_type', 'expiry', 'tags', 'decorators'];

        foreach ($bindings as $id => $definition) {
            if (!is_array($definition)) {
                $this->errors[] = "Binding definition for '{$id}' must be an array.";
                continue;
            }
            if (!isset($definition['factory'])) {
                $this->errors[] = "Missing required 'factory' key for binding ID: {$id}.";
            }

            $unknownKeys = array_diff(array_keys($definition), $validKeys);
            if (!empty($unknownKeys)) {
                $this->logger->warning("Unknown configuration keys found for binding '{$id}': " . implode(', ', $unknownKeys));
            }
        }
    }
}

