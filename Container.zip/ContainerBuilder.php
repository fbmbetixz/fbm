<?php

namespace Core\Container;

use Psr\Container\ContainerInterface;
use Psr\Log\LoggerInterface;
use Psr\Log\NullLogger;
use Core\Container\Exceptions\ContainerException;
use Core\Container\Interfaces\ArchitecturalRule;
use Core\Container\Interfaces\BindingRegistry;
use Core\Container\Interfaces\ContainerExtension;
use Core\Container\Interfaces\ContextManager;
use Core\Container\Interfaces\DelegationPolicy;
use Core\Container\Interfaces\DocGenerator;
use Core\Container\Interfaces\EventDispatcher;
use Core\Container\Interfaces\Monitoring;
use Core\Container\Interfaces\SecretManager;
use Throwable;

/**
 * ContainerBuilder adalah kelas pembangun (builder) yang memfasilitasi
 * konfigurasi dan konstruksi instance NextLevelContainer.
 * Ini memungkinkan konfigurasi yang fleksibel dan terpisah dari logika kontainer inti.
 *
 * @package Core\Container
 */
class ContainerBuilder
{
    /** @var BindingRegistry|null Registri binding yang akan digunakan. */
    private ?BindingRegistry $registry = null;
    /** @var Monitoring|null Sistem monitoring yang akan digunakan. */
    private ?Monitoring $monitor = null;
    /** @var EventDispatcher|null Dispatcher peristiwa yang akan digunakan. */
    private ?EventDispatcher $events = null;
    /** @var SnapshotManager|null Manajer snapshot yang akan digunakan. */
    private ?SnapshotManager $snapshot = null;
    /** @var SecretManager|null Manajer rahasia yang akan digunakan. */
    private ?SecretManager $secrets = null;
    /** @var ContextManager|null Manajer konteks yang akan digunakan. */
    private ?ContextManager $context = null;
    /** @var DocGenerator|null Generator dokumentasi yang akan digunakan. */
    private ?DocGenerator $doc = null;
    /** @var ContainerExtension[] Daftar ekstensi kontainer yang akan didaftarkan. */
    private array $extensions = [];
    /** @var ArchitecturalRule[] Daftar aturan arsitektur yang akan divalidasi. */
    private array $rules = [];
    /** @var LoggerInterface|null Logger yang akan digunakan. */
    private ?LoggerInterface $logger = null;
    /** @var bool Menentukan apakah penulisan ulang binding diizinkan dalam mode ketat. */
    private bool $strictOverwrite = false;
    /** @var ContainerInterface|null Kontainer induk jika kontainer ini adalah anak. */
    private ?ContainerInterface $parentContainer = null;
    /** @var DelegationPolicy|null Kebijakan delegasi ke kontainer induk. */
    private ?DelegationPolicy $delegationPolicy = null;
    /** @var SecurityPolicy|null Kebijakan keamanan untuk kontainer. */
    private ?SecurityPolicy $securityPolicy = null;

    /**
     * Menetapkan implementasi BindingRegistry.
     *
     * @param BindingRegistry $registry Implementasi BindingRegistry.
     * @return $this
     */
    public function withBindingRegistry(BindingRegistry $registry): self
    {
        $this->registry = $registry;
        return $this;
    }

    /**
     * Menetapkan implementasi Monitoring.
     *
     * @param Monitoring $monitor Implementasi Monitoring.
     * @return $this
     */
    public function withMonitoring(Monitoring $monitor): self
    {
        $this->monitor = $monitor;
        return $this;
    }

    /**
     * Menetapkan implementasi EventDispatcher.
     *
     * @param EventDispatcher $events Implementasi EventDispatcher.
     * @return $this
     */
    public function withEventDispatcher(EventDispatcher $events): self
    {
        $this->events = $events;
        return $this;
    }

    /**
     * Menetapkan implementasi SnapshotManager.
     *
     * @param SnapshotManager $snapshot Implementasi SnapshotManager.
     * @return $this
     */
    public function withSnapshotManager(SnapshotManager $snapshot): self
    {
        $this->snapshot = $snapshot;
        return $this;
    }

    /**
     * Menetapkan implementasi SecretManager.
     *
     * @param SecretManager $secrets Implementasi SecretManager.
     * @return $this
     */
    public function withSecretManager(SecretManager $secrets): self
    {
        $this->secrets = $secrets;
        return $this;
    }

    /**
     * Menetapkan implementasi ContextManager.
     *
     * @param ContextManager $context Implementasi ContextManager.
     * @return $this
     */
    public function withContextManager(ContextManager $context): self
    {
        $this->context = $context;
        return $this;
    }

    /**
     * Menetapkan implementasi DocGenerator.
     *
     * @param DocGenerator $doc Implementasi DocGenerator.
     * @return $this
     */
    public function withDocGenerator(DocGenerator $doc): self
    {
        $this->doc = $doc;
        return $this;
    }

    /**
     * Menambahkan ekstensi kontainer.
     *
     * @param ContainerExtension $extension Instance ekstensi yang akan ditambahkan.
     * @return $this
     */
    public function withExtension(ContainerExtension $extension): self
    {
        $this->extensions[] = $extension;
        return $this;
    }

    /**
     * Menambahkan aturan arsitektur untuk validasi.
     *
     * @param ArchitecturalRule $rule Instance aturan arsitektur.
     * @return $this
     */
    public function withArchitecturalRule(ArchitecturalRule $rule): self
    {
        $this->rules[] = $rule;
        return $this;
    }

    /**
     * Menetapkan logger untuk kontainer.
     *
     * @param LoggerInterface $logger Implementasi LoggerInterface.
     * @return $this
     */
    public function withLogger(LoggerInterface $logger): self
    {
        $this->logger = $logger;
        return $this;
    }

    /**
     * Mengatur mode penulisan ulang ketat untuk binding.
     * Jika diaktifkan, binding yang sudah ada tidak dapat ditimpa.
     *
     * @param bool $strict True untuk mengaktifkan mode ketat, false untuk menonaktifkan.
     * @return $this
     */
    public function withStrictOverwrite(bool $strict = true): self
    {
        $this->strictOverwrite = $strict;
        return $this;
    }

    /**
     * Menetapkan kebijakan keamanan untuk kontainer.
     *
     * @param SecurityPolicy $policy Instance SecurityPolicy.
     * @return $this
     */
    public function withSecurityPolicy(SecurityPolicy $policy): self
    {
        $this->securityPolicy = $policy;
        return $this;
    }

    /**
     * Menetapkan kontainer induk untuk delegasi.
     * Mencegah hierarki kontainer melingkar.
     *
     * @param ContainerInterface $parent Kontainer induk.
     * @param DelegationPolicy|null $policy Kebijakan delegasi. Jika null, AllowAllPolicy akan digunakan.
     * @return $this
     * @throws ContainerException Jika hierarki kontainer melingkar terdeteksi.
     */
    public function withParent(ContainerInterface $parent, ?DelegationPolicy $policy = null): self
    {
        $p = $parent;
        while ($p !== null) {
            if ($p === $this) {
                throw new ContainerException("Circular container hierarchy detected.");
            }
            // Asumsi kontainer induk juga memiliki metode getParent()
            $p = method_exists($p, 'getParent') ? $p->getParent() : null;
        }
        $this->parentContainer = $parent;
        $this->delegationPolicy = $policy;
        return $this;
    }

    /**
     * Membangun dan mengembalikan instance NextLevelContainer berdasarkan konfigurasi builder.
     * Menginisialisasi komponen default jika tidak disediakan dan menjalankan validasi aturan arsitektur.
     *
     * @return NextLevelContainer Instance kontainer yang telah dibangun.
     * @throws ContainerException Jika validasi aturan arsitektur gagal atau pendaftaran ekstensi gagal.
     */
    public function build(): NextLevelContainer
    {
        // Inisialisasi komponen default jika tidak disediakan
        $registry = $this->registry ?? new InMemoryBindingRegistry();
        $monitor = $this->monitor ?? new DefaultMonitoring();
        $events = $this->events ?? new DefaultEventDispatcher();
        $snapshot = $this->snapshot ?? new DefaultSnapshotManager();
        $secrets = $this->secrets ?? new DefaultSecretManager();
        $context = $this->context ?? new DefaultContextManager();
        $doc = $this->doc ?? new DefaultDocGenerator();
        $logger = $this->logger ?? new NullLogger(); // Menggunakan NullLogger jika tidak ada logger yang diberikan

        // Jalankan validasi aturan arsitektur jika ada aturan yang terdaftar
        if (!empty($this->rules)) {
            $validator = new RuleValidator($this->rules);
            try {
                $validator->validateAll($registry->getAllBindings());
            } catch (Throwable $e) {
                $logger->critical('Architectural rule validation failed during build: ' . $e->getMessage(), ['exception' => $e]);
                throw new ContainerException("Container build failed due to architectural rule violation.", 0, $e);
            }
        }

        // Buat instance kontainer utama
        $container = new NextLevelContainer(
            $registry, $monitor, $events, $snapshot, $secrets, $context,
            $doc, $logger, $this->extensions, $this->strictOverwrite,
            $this->parentContainer, $this->delegationPolicy
        );

        // Daftarkan ekstensi ke kontainer yang baru dibuat
        foreach ($this->extensions as $extension) {
            try {
                $extension->register($container, $this);
            } catch (Throwable $e) {
                $logger->critical('Extension registration failed', ['extension' => get_class($extension), 'error' => $e->getMessage()]);
                throw new ContainerException('Extension ' . get_class($extension) . ' failed to register: ' . $e->getMessage(), 0, $e);
            }
        }

        return $container;
    }
}

